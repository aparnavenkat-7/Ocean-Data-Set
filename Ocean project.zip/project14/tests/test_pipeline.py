import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from opm.config import BAND_COLS, Config  # noqa: E402
from opm.drift import DriftDetector, psi  # noqa: E402
from opm.processing import FEATURE_COLS, LEAKY_COLS, DataProcessor  # noqa: E402
from opm.synthetic import generate_dataset  # noqa: E402
from opm.trainer import ConvergenceTrainer, DriftForecaster  # noqa: E402


@pytest.fixture(scope="module")
def cfg():
    return Config(n_days=40, grid_nx=12, grid_ny=12, max_iter=60)


@pytest.fixture(scope="module")
def prepared(cfg):
    raw = generate_dataset(cfg)
    proc = DataProcessor(cfg).fit(DataProcessor(cfg).train_days(raw))
    feats = proc.transform(raw)
    return raw, proc, feats


def test_cleaning_removes_duplicates_and_nans(prepared, cfg):
    raw, _, feats = prepared
    assert len(feats) == cfg.n_days * cfg.grid_nx * cfg.grid_ny
    assert feats[BAND_COLS].isna().sum().sum() == 0
    assert feats.duplicated(["day", "cell_id"]).sum() == 0


def test_no_label_leakage_in_features():
    assert not set(FEATURE_COLS) & set(LEAKY_COLS)


def test_time_split_is_chronological(prepared):
    _, proc, feats = prepared
    tr, va, te = proc.time_split(feats)
    assert tr.day.max() < va.day.min() <= va.day.max() < te.day.min()


def test_recent_split_keeps_val_test_in_new_regime(prepared):
    _, proc, feats = prepared
    tr, va, te = proc.time_split(feats, recent_start_day=30)
    assert va.day.min() >= 30 and te.day.min() > va.day.max()
    assert tr.day.max() < va.day.min()


def test_divergence_negative_at_gyre_core(prepared, cfg):
    _, _, feats = prepared
    core = feats[(feats.x.abs() < 0.2) & (feats.y.abs() < 0.2)] if "x" in feats else None
    if core is not None and len(core):
        assert core.div_smooth.mean() < feats.div_smooth.mean()


def test_classifier_beats_divergence_baseline(prepared, cfg):
    _, proc, feats = prepared
    tr, va, te = proc.time_split(feats)
    res = ConvergenceTrainer(cfg).train(tr, va, te)
    assert res.metrics["test_pr_auc"] > 0.5
    assert res.metrics["test_pr_auc"] >= res.metrics["test_baseline_pr_auc"] - 0.02


def test_forecaster_runs(prepared, cfg):
    _, proc, feats = prepared
    res = DriftForecaster(cfg).train(*proc.time_split(feats))
    assert np.isfinite(res.metrics["test_rmse_mean"])


def test_psi_zero_for_identical():
    f = np.array([0.1] * 10)
    assert psi(f, f) == pytest.approx(0.0, abs=1e-9)


def test_drift_detector_quiet_on_same_regime_and_loud_on_drift(prepared, cfg):
    raw, proc, feats = prepared
    tr, va, te = proc.time_split(feats)
    trainer = ConvergenceTrainer(cfg)
    res = trainer.train(tr, va, te)
    det = DriftDetector(cfg).fit(tr, FEATURE_COLS, res.model.predict_proba(te[FEATURE_COLS])[:, 1],
                                 res.metrics["test_roc_auc"])
    same = proc.transform(generate_dataset(cfg, 40, 15, False, seed=7), with_targets=False)
    drifted = proc.transform(generate_dataset(cfg, 40, 15, True, seed=7), with_targets=False)
    r_same = det.check(same, res.model.predict_proba(same[FEATURE_COLS])[:, 1])
    r_drift = det.check(drifted, res.model.predict_proba(drifted[FEATURE_COLS])[:, 1])
    assert not r_same.drift_detected
    assert r_drift.drift_detected and r_drift.n_alert > r_same.n_alert


def test_reference_is_consistent_after_regime_retrain(cfg):
    """Regression: after a retrain, features/predictions/AUC must share ONE reference window (val+test of the
    regime the model was validated on). Same-regime data must stay quiet, the old regime must alert."""
    import pandas as pd
    from sklearn.metrics import roc_auc_score
    old = generate_dataset(cfg)                                              # days 0-39, healthy
    new = generate_dataset(cfg, 40, 20, True, seed=3)                        # days 40-59, drifted regime
    raw = pd.concat([old, new], ignore_index=True)
    proc = DataProcessor(cfg).fit(DataProcessor(cfg).train_days(old))
    feats = proc.transform(raw)
    tr, va, te = proc.time_split(feats, recent_start_day=40)
    trainer = ConvergenceTrainer(cfg)
    res = trainer.train(tr, va, te)
    ref = pd.concat([va, te], ignore_index=True)
    p_ref = res.model.predict_proba(ref[FEATURE_COLS])[:, 1]
    det = DriftDetector(cfg).fit(ref, FEATURE_COLS, p_ref, float(roc_auc_score(ref["convergence_zone"], p_ref)))

    def check(sim):
        f = proc.transform(generate_dataset(cfg, 60, 15, sim, seed=11), with_targets=False)
        return det.check(f, res.model.predict_proba(f[FEATURE_COLS])[:, 1])

    assert not check(True).drift_detected      # same (drifted) regime as the reference
    assert check(False).drift_detected         # regime changed back -> legitimate alert
