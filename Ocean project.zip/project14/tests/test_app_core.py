"""Unit tests for the analytics functions behind the web app (app/core.py)."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import core  # noqa: E402


@pytest.fixture
def messy():
    rng = np.random.default_rng(0)
    n = 400
    df = pd.DataFrame({"x": rng.normal(10, 2, n), "grp": rng.choice(["a", "b", "c"], n)})
    df["y"] = 3 * df["x"] + rng.normal(0, 1, n) + (df["grp"] == "c") * 5
    df["label"] = (df["y"] > df["y"].median()).astype(int)
    df["txt_num"] = df["x"].round(2).astype(object)
    df.loc[[3, 9, 15], "txt_num"] = ["error", "--", "###"]
    df.loc[[5, 6], "x"] = np.nan
    df.loc[[7], "grp"] = "N/A"
    df.loc[[20, 21, 22], "y"] = df["y"].max() * 5                      # outliers
    return pd.concat([df, df.iloc[:5]], ignore_index=True)             # 5 duplicates


def test_types_and_corrupted_detection(messy):
    kinds = core.classify_columns(messy).set_index("column")["data type"]
    assert kinds["x"] == "Quantitative - continuous" and kinds["grp"] == "Qualitative - nominal"
    assert kinds["txt_num"].startswith("Quantitative - stored as text")
    assert core.detect_corrupted(messy)["column"].tolist() == ["txt_num"]


def test_cleaning_removes_all_problems_and_logs(messy):
    out, log = core.clean_dataframe(messy, core.CleanConfig())
    assert out.isna().sum().sum() == 0 and out.duplicated().sum() == 0
    assert core.is_numeric(out["txt_num"]) and "N/A" not in set(out["grp"])
    assert len(log) >= 5 and len(out) == len(messy) - 5


def test_cleaning_drop_options(messy):
    out, _ = core.clean_dataframe(messy, core.CleanConfig(drop_cols=["label"], num_strategy="none", cat_strategy="none", row_missing_max=0))
    assert "label" not in out.columns and out.isna().sum().sum() == 0


@pytest.mark.parametrize("strategy", ["mean", "median", "knn", "constant"])
def test_numeric_imputation_strategies(messy, strategy):
    out, _ = core.clean_dataframe(messy, core.CleanConfig(num_strategy=strategy))
    assert out["x"].isna().sum() == 0


def test_outlier_detection_and_treatment(messy):
    assert core.outlier_summary(messy, ["y"], "iqr", 1.5)["outliers"].iloc[0] >= 3
    capped, _ = core.treat_outliers(messy, ["y"], "iqr", 1.5, "cap (winsorize)")
    assert capped["y"].max() < messy["y"].max() and len(capped) == len(messy)
    removed, _ = core.treat_outliers(messy, ["y"], "iqr", 1.5, "remove rows")
    assert len(removed) < len(messy)


def _prepared(messy):
    """Pipeline order: clean (step 2) -> treat outliers (step 3) -> analyse (steps 4-6)."""
    clean, _ = core.clean_dataframe(messy, core.CleanConfig())
    return core.treat_outliers(clean, ["y"], "iqr", 1.5, "cap (winsorize)")[0]


def test_outlier_treatment_rescues_the_regression_fit(messy):
    clean, _ = core.clean_dataframe(messy, core.CleanConfig())
    before = core.fit_regression(clean, "y", ["x", "grp"])["metrics"]["R2 (test)"]
    after = core.fit_regression(_prepared(messy), "y", ["x", "grp"])["metrics"]["R2 (test)"]
    assert before < 0.2 and after > 0.8


def test_hypothesis_tests(messy):
    clean = _prepared(messy)
    t = core.t_test(clean, "y", "grp", "a", "c")
    assert t["p"] < 0.001 and abs(t["cohens_d"]) > 0.5
    a = core.anova(clean, "y", "grp")
    assert a["p"] < 0.001 and 0 < a["eta2"] < 1
    chi = core.chi_square(pd.DataFrame({"g": clean["grp"], "l": clean["label"]}), "g", "l")
    assert 0 <= chi["cramers_v"] <= 1 and chi["dof"] == 2


def test_driver_ranking_finds_true_driver(messy):
    clean, _ = core.clean_dataframe(messy, core.CleanConfig())
    rk = core.driver_ranking(clean[["x", "grp", "y"]], "y")
    assert rk.iloc[0]["feature"] == "x"


def test_leakage_detection_flags_label_in_disguise(messy):
    clean, _ = core.clean_dataframe(messy, core.CleanConfig())
    sus = core.leakage_suspects(clean, "label", ["x", "y", "grp"])
    assert "y" in sus and "x" not in sus          # label was defined as y > median


def test_regression_and_classification(messy):
    clean = _prepared(messy)
    reg = core.fit_regression(clean, "y", ["x", "grp"])
    assert reg["metrics"]["R2 (test)"] > 0.8
    clf = core.fit_classification(clean, "label", ["x", "grp"], ["Logistic Regression", "SVM (RBF kernel)"])
    assert clf["binary"] and all(v["metrics"]["ROC-AUC"] > 0.8 for v in clf["results"].values())


def test_psi_detects_shift(messy):
    clean, _ = core.clean_dataframe(messy, core.CleanConfig())
    same = core.psi_table(clean, clean.sample(frac=1, random_state=1), ["x", "y"])
    shifted = clean.assign(x=clean["x"] + 2 * clean["x"].std())
    drift = core.psi_table(clean, shifted, ["x", "y"])
    assert (same["status"] == "ok").all() and drift.set_index("feature").loc["x", "status"] == "ALERT"
