"""End-to-end UI test: walk every page of the web app headlessly using the built-in sample dataset."""
from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

APP = str(Path(__file__).resolve().parents[1] / "app" / "app.py")


def _advance(at, i):
    at.checkbox(key=f"verify_{i}").check().run()
    at.button(key=f"proceed_{i}").click().run()


def test_full_walkthrough_and_back_navigation():
    at = AppTest.from_file(APP, default_timeout=300).run()
    assert not at.exception
    for i in range(5):                                           # upload, clean, EDA, descriptive, diagnostic
        _advance(at, i)
        assert not at.exception, f"error after step {i + 1}: {[e.value for e in at.exception]}"
    assert at.session_state["step"] == 5
    assert at.session_state["data"][1].isna().sum().sum() == 0   # cleaned data is complete

    at.button(key="btn_train").click().run()                     # simple regression
    assert not at.exception
    at.selectbox(key="w_ptarget").set_value("convergence_zone").run()
    assert any("leakage" in w.value.lower() for w in at.warning)
    at.button(key="btn_train").click().run()                     # classification
    assert not at.exception
    _advance(at, 5)
    assert at.session_state["step"] == 6 and not at.exception    # report + monitoring page renders
    assert sorted(at.session_state["done"]) == [0, 1, 2, 3, 4, 5]

    at.button(key="nav_1").click().run()                         # go back, change a decision
    at.selectbox(key="w_num").set_value("Mean").run()
    _advance(at, 1)
    assert not at.exception
    assert sorted(at.session_state["done"]) == [0, 1]            # downstream steps were reset
