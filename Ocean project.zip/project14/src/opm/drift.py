"""Concept / data drift detection: PSI + KS per feature, prediction drift, and delayed-label performance drop."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp
from sklearn.metrics import roc_auc_score

from .config import Config


def psi(ref_frac: np.ndarray, cur_frac: np.ndarray, eps: float = 1e-4) -> float:
    r, c = np.clip(ref_frac, eps, None), np.clip(cur_frac, eps, None)
    return float(np.sum((c - r) * np.log(c / r)))


@dataclass
class DriftReport:
    drift_detected: bool
    severity: str                       # ok | warn | alert
    n_features: int
    n_alert: int
    n_warn: int
    alert_share: float
    prediction_psi: float | None
    ref_auc: float | None
    cur_auc: float | None
    auc_drop: float | None
    concept_drift: bool
    reasons: list[str] = field(default_factory=list)
    features: list[dict] = field(default_factory=list)   # sorted by PSI desc

    def to_dict(self) -> dict:
        return asdict(self)

    def top(self, k: int = 5) -> list[dict]:
        return self.features[:k]


class DriftDetector:
    """Fit on the reference (training) window; call `check` on each new production batch."""

    def __init__(self, cfg: Config, n_bins: int = 10):
        self.cfg, self.n_bins = cfg, n_bins
        self.edges_: dict[str, np.ndarray] = {}
        self.ref_frac_: dict[str, np.ndarray] = {}
        self.ref_sample_: dict[str, np.ndarray] = {}
        self.pred_edges_: np.ndarray | None = None
        self.pred_frac_: np.ndarray | None = None
        self.ref_auc_: float | None = None

    @staticmethod
    def _bin_frac(x: np.ndarray, edges: np.ndarray) -> np.ndarray:
        idx = np.clip(np.searchsorted(edges, x, side="right") - 1, 0, len(edges) - 2)
        return np.bincount(idx, minlength=len(edges) - 1) / max(len(x), 1)

    def _edges(self, x: np.ndarray) -> np.ndarray:
        e = np.unique(np.quantile(x, np.linspace(0, 1, self.n_bins + 1)))
        e[0], e[-1] = -np.inf, np.inf
        return e

    def fit(self, ref: pd.DataFrame, feature_cols: list[str], ref_proba: np.ndarray | None = None,
            ref_auc: float | None = None) -> "DriftDetector":
        rng = np.random.default_rng(self.cfg.seed)
        for c in feature_cols:
            x = ref[c].dropna().to_numpy()
            self.edges_[c] = self._edges(x)
            self.ref_frac_[c] = self._bin_frac(x, self.edges_[c])
            self.ref_sample_[c] = rng.choice(x, size=min(3000, len(x)), replace=False)
        if ref_proba is not None:
            self.pred_edges_ = self._edges(ref_proba)
            self.pred_frac_ = self._bin_frac(ref_proba, self.pred_edges_)
        self.ref_auc_ = ref_auc
        return self

    def check(self, cur: pd.DataFrame, cur_proba: np.ndarray | None = None,
              y_true: np.ndarray | None = None) -> DriftReport:
        cfg, rows = self.cfg, []
        for c, edges in self.edges_.items():
            x = cur[c].dropna().to_numpy()
            p = psi(self.ref_frac_[c], self._bin_frac(x, edges))
            ks = ks_2samp(self.ref_sample_[c], x)
            sev = "alert" if p >= cfg.psi_alert else "warn" if p >= cfg.psi_warn else "ok"
            rows.append({"feature": c, "psi": round(p, 4), "ks_stat": round(float(ks.statistic), 4),
                         "ks_p": float(ks.pvalue), "severity": sev})
        rows.sort(key=lambda r: -r["psi"])
        n_alert = sum(r["severity"] == "alert" for r in rows)
        n_warn = sum(r["severity"] == "warn" for r in rows)
        share = n_alert / max(len(rows), 1)

        pred_psi = None
        if cur_proba is not None and self.pred_edges_ is not None:
            pred_psi = psi(self.pred_frac_, self._bin_frac(cur_proba, self.pred_edges_))

        cur_auc = auc_drop = None
        concept = False
        if y_true is not None and cur_proba is not None and len(np.unique(y_true)) == 2:
            cur_auc = float(roc_auc_score(y_true, cur_proba))
            if self.ref_auc_ is not None:
                auc_drop = self.ref_auc_ - cur_auc
                concept = auc_drop >= cfg.perf_drop_alert

        reasons = []
        if share >= cfg.drift_feature_share:
            reasons.append(f"{n_alert}/{len(rows)} features in PSI alert (>= {cfg.psi_alert})")
        if pred_psi is not None and pred_psi >= cfg.psi_alert:
            reasons.append(f"prediction distribution shifted (PSI={pred_psi:.2f})")
        if concept:
            reasons.append(f"ROC-AUC dropped {auc_drop:.3f} vs reference (concept drift)")
        detected = bool(reasons)
        severity = "alert" if detected else ("warn" if n_warn + n_alert > 0 else "ok")
        return DriftReport(detected, severity, len(rows), n_alert, n_warn, share, pred_psi,
                           self.ref_auc_, cur_auc, auc_drop, concept, reasons, rows)
