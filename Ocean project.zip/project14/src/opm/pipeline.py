"""Orchestration: Prefect flows (graceful no-op fallback if Prefect is not installed).

training_flow   : ingest -> clean/features -> EDA -> train classifier + forecaster (MLflow) ->
                  champion/challenger promotion -> fit drift reference -> persist bundle
monitoring_flow : new batch -> features -> score -> drift check -> MLflow log -> alert -> optional retrain
"""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

import joblib
import mlflow
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from .alerts import AlertManager
from .config import Config
from .drift import DriftDetector, DriftReport
from .eda import EDAReport
from .processing import FEATURE_COLS, LABEL_COL, TARGET_UV, DataProcessor
from .synthetic import generate_dataset
from .tracking import Tracker
from .trainer import ConvergenceTrainer, DriftForecaster

log = logging.getLogger("opm.pipeline")

try:  # ------------------------------------------------------------------ Prefect (optional)
    from prefect import flow, task
    from prefect.cache_policies import NO_CACHE
    HAS_PREFECT = True
except Exception:  # pragma: no cover
    HAS_PREFECT = False
    NO_CACHE = None

    def _passthrough(*args, **kwargs):
        if len(args) == 1 and callable(args[0]) and not kwargs:
            return args[0]
        return lambda fn: fn

    task = flow = _passthrough


def _task(**kw):
    return task(cache_policy=NO_CACHE, **kw) if HAS_PREFECT else task()


CHAMPION = "champion_bundle.joblib"
FORECASTER = "forecaster_bundle.joblib"
REFERENCE = "reference_raw.csv.gz"


# ====================================================================== tasks
@_task()
def ingest_reference(cfg: Config) -> pd.DataFrame:
    """Swap generate_dataset for your real loader (same column contract)."""
    raw = generate_dataset(cfg)
    log.info("ingested %d raw rows over %d days", len(raw), raw["day"].nunique())
    return raw


@_task()
def ingest_batch(cfg: Config, start_day: int, n_days: int, simulate_drift: bool) -> pd.DataFrame:
    return generate_dataset(cfg, start_day=start_day, n_days=n_days, simulate_drift=simulate_drift,
                            seed=cfg.seed + 1000)


@_task()
def build_features(cfg: Config, raw: pd.DataFrame, recent_start_day: int | None):
    proc = DataProcessor(cfg)
    ref_days = raw if recent_start_day is None else raw[raw["day"] < recent_start_day]
    proc.fit(proc.train_days(ref_days))
    feats = proc.transform(raw)
    tr, va, te = proc.time_split(feats, recent_start_day)
    log.info("split rows train/val/test = %d/%d/%d", len(tr), len(va), len(te))
    return proc, feats, tr, va, te


@_task()
def eda_task(cfg: Config, raw: pd.DataFrame, feats: pd.DataFrame) -> dict:
    return EDAReport(cfg).run(raw, feats)


@_task()
def train_classifier(cfg: Config, tracker: Tracker, proc, tr, va, te, tag: str) -> dict:
    trainer = ConvergenceTrainer(cfg)
    with tracker.run(f"{trainer.name}-{tag}", {"phase": "2", "model": trainer.name, "trigger": tag}):
        res = trainer.train(tr, va, te)
        version = tracker.log_training(trainer, res, cfg.classifier_name, tr[trainer.feature_cols])
        champ = _load(cfg, CHAMPION)
        promote = champ is None
        if champ is not None:                      # champion/challenger on the SAME new test set
            cm = trainer.evaluate_bundle(champ["model"], champ["threshold"], te)
            mlflow.log_metrics({"champion_test_pr_auc": cm["pr_auc"], "champion_test_roc_auc": cm["roc_auc"]})
            promote = res.metrics["test_pr_auc"] > cm["pr_auc"]
            log.info("challenger PR-AUC %.3f vs champion %.3f -> %s", res.metrics["test_pr_auc"], cm["pr_auc"],
                     "PROMOTE" if promote else "keep champion")
        mlflow.set_tag("promoted", str(promote))
    if promote:
        tracker.promote(cfg.classifier_name, version)
        # ONE reference window for features, predictions and AUC: the held-out (val+test) data of the regime this
        # model was validated on. Mixing windows (e.g. train features vs. test predictions) causes false alarms
        # after a retrain, when val/test are all new-regime but train is mostly old-regime.
        ref = pd.concat([va, te], ignore_index=True)
        p_ref = res.model.predict_proba(ref[trainer.feature_cols])[:, 1]
        det = DriftDetector(cfg).fit(ref, trainer.feature_cols, ref_proba=p_ref,
                                     ref_auc=float(roc_auc_score(ref[LABEL_COL], p_ref)))
        _save(cfg, CHAMPION, {"model": res.model, "threshold": res.threshold, "feature_cols": trainer.feature_cols,
                              "processor": proc, "detector": det, "version": version,
                              "trained_at": datetime.utcnow().isoformat(), "metrics": res.metrics})
    return {"promoted": promote, "version": version, "metrics": res.metrics}


@_task()
def train_forecaster(cfg: Config, tracker: Tracker, tr, va, te, tag: str) -> dict:
    trainer = DriftForecaster(cfg)
    with tracker.run(f"{trainer.name}-{tag}", {"phase": "2", "model": trainer.name, "trigger": tag}):
        res = trainer.train(tr, va, te)
        version = tracker.log_training(trainer, res, cfg.forecaster_name, tr[trainer.feature_cols])
        champ = _load(cfg, FORECASTER)
        promote = champ is None
        if champ is not None:
            t = te.dropna(subset=TARGET_UV)
            pred = champ["model"].predict(t[trainer.feature_cols])
            champ_rmse = float(np.mean([np.sqrt(np.mean((t[c] - pred[:, i]) ** 2)) for i, c in enumerate(TARGET_UV)]))
            mlflow.log_metric("champion_test_rmse_mean", champ_rmse)
            promote = res.metrics["test_rmse_mean"] < champ_rmse
        mlflow.set_tag("promoted", str(promote))
    if promote:
        tracker.promote(cfg.forecaster_name, version)
        _save(cfg, FORECASTER, {"model": res.model, "feature_cols": trainer.feature_cols, "version": version})
    return {"promoted": promote, "version": version, "metrics": res.metrics}


@_task()
def score_and_check_drift(cfg: Config, bundle: dict, raw_batch: pd.DataFrame, labels_available: bool):
    feats = bundle["processor"].transform(raw_batch, with_targets=False)
    proba = bundle["model"].predict_proba(feats[bundle["feature_cols"]])[:, 1]
    y = feats[LABEL_COL].to_numpy() if labels_available and LABEL_COL in feats else None
    report = bundle["detector"].check(feats, proba, y)
    return feats, proba, report


@_task()
def log_and_alert(cfg: Config, tracker: Tracker, report: DriftReport, label: str) -> bool:
    with tracker.run(f"drift-check-{label}", {"phase": "monitoring"}):
        tracker.log_drift(report, label)
    return AlertManager(cfg).send(report, label)


# ====================================================================== flows
@flow(name="project14-training", validate_parameters=False)
def training_flow(cfg: Config | None = None, raw: pd.DataFrame | None = None, run_eda: bool = True,
                  tag: str = "initial", recent_start_day: int | None = None) -> dict:
    cfg = cfg or Config()
    cfg.ensure_dirs()
    tracker = Tracker(cfg)
    raw = ingest_reference(cfg) if raw is None else raw
    raw.to_csv(Path(cfg.data_dir) / REFERENCE, index=False)
    proc, feats, tr, va, te = build_features(cfg, raw, recent_start_day)
    eda = eda_task(cfg, raw, feats) if run_eda else {}
    clf = train_classifier(cfg, tracker, proc, tr, va, te, tag)
    fc = train_forecaster(cfg, tracker, tr, va, te, tag)
    return {"classifier": clf, "forecaster": fc, "eda": eda}


@flow(name="project14-monitoring", validate_parameters=False)
def monitoring_flow(cfg: Config | None = None, n_days: int = 20, simulate_drift: bool = False,
                    start_day: int | None = None, labels_available: bool = True,
                    auto_retrain: bool | None = None) -> dict:
    cfg = cfg or Config()
    auto_retrain = cfg.auto_retrain if auto_retrain is None else auto_retrain
    bundle = _load(cfg, CHAMPION)
    if bundle is None:
        raise RuntimeError("No champion model found - run the training flow first.")
    ref = pd.read_csv(Path(cfg.data_dir) / REFERENCE)
    start_day = int(ref["day"].max()) + 1 if start_day is None else start_day
    raw_batch = ingest_batch(cfg, start_day, n_days, simulate_drift)
    _, _, report = score_and_check_drift(cfg, bundle, raw_batch, labels_available)
    label = f"days{start_day}-{start_day + n_days - 1}{'-drifted' if simulate_drift else ''}"
    tracker = Tracker(cfg)
    alerted = log_and_alert(cfg, tracker, report, label)

    out = {"batch": label, "report": report, "alerted": alerted, "retrained": False}
    if report.drift_detected and auto_retrain:
        log.warning("drift detected -> retraining on reference + new batch")
        raw_all = pd.concat([ref, raw_batch], ignore_index=True)
        out["retrain"] = training_flow(cfg, raw=raw_all, run_eda=False, tag=f"retrain-{label}",
                                       recent_start_day=start_day)
        out["retrained"] = True
    return out


# ====================================================================== io helpers
def _save(cfg: Config, name: str, obj) -> None:
    joblib.dump(obj, Path(cfg.models_dir) / name)


def _load(cfg: Config, name: str):
    p = Path(cfg.models_dir) / name
    return joblib.load(p) if p.exists() else None
