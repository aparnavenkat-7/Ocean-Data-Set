"""Phase 2 - OOP model layer. BaseTrainer defines the contract; two concrete trainers implement it."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import (average_precision_score, brier_score_loss, f1_score, mean_squared_error,
                             precision_recall_curve, precision_score, r2_score, recall_score, roc_auc_score)
from sklearn.multioutput import MultiOutputRegressor

from .config import Config
from .processing import FEATURE_COLS, LABEL_COL, TARGET_UV


@dataclass
class TrainResult:
    model: Any
    params: dict
    metrics: dict
    feature_names: list[str]
    importances: dict[str, float] = field(default_factory=dict)
    threshold: float | None = None


class BaseTrainer(ABC):
    name: str = "base"
    primary_metric: str = ""
    higher_is_better: bool = True

    def __init__(self, cfg: Config, feature_cols: list[str] | None = None):
        self.cfg = cfg
        self.feature_cols = feature_cols or FEATURE_COLS

    @abstractmethod
    def build_model(self) -> Any: ...

    @abstractmethod
    def _fit_eval(self, tr: pd.DataFrame, va: pd.DataFrame, te: pd.DataFrame) -> TrainResult: ...

    def params(self) -> dict:
        return {"max_iter": self.cfg.max_iter, "learning_rate": self.cfg.learning_rate,
                "max_depth": self.cfg.max_depth, "n_features": len(self.feature_cols), "seed": self.cfg.seed}

    def train(self, train: pd.DataFrame, val: pd.DataFrame, test: pd.DataFrame) -> TrainResult:
        return self._fit_eval(train, val, test)

    def _perm_importance(self, model, X, y, scoring) -> dict[str, float]:
        Xs = X.sample(min(len(X), 3000), random_state=self.cfg.seed)
        ys = y.loc[Xs.index]
        r = permutation_importance(model, Xs, ys, n_repeats=3, random_state=self.cfg.seed, scoring=scoring)
        return dict(sorted(zip(X.columns, r.importances_mean.round(5)), key=lambda kv: -kv[1]))


class ConvergenceTrainer(BaseTrainer):
    """Classifies whether a cell is a plastic convergence zone."""
    name = "convergence_classifier"
    primary_metric = "test_pr_auc"

    def build_model(self):
        return HistGradientBoostingClassifier(
            max_iter=self.cfg.max_iter, learning_rate=self.cfg.learning_rate, max_depth=self.cfg.max_depth,
            class_weight="balanced", random_state=self.cfg.seed)

    @staticmethod
    def best_f1_threshold(y, p) -> float:
        prec, rec, thr = precision_recall_curve(y, p)
        f1 = 2 * prec[:-1] * rec[:-1] / np.clip(prec[:-1] + rec[:-1], 1e-9, None)
        return float(thr[int(np.argmax(f1))])

    @staticmethod
    def score(y, p, thr) -> dict:
        pred = (p >= thr).astype(int)
        return {"roc_auc": roc_auc_score(y, p), "pr_auc": average_precision_score(y, p),
                "f1": f1_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
                "recall": recall_score(y, pred), "brier": brier_score_loss(y, p)}

    def _fit_eval(self, tr, va, te) -> TrainResult:
        X = lambda d: d[self.feature_cols]
        model = self.build_model().fit(X(tr), tr[LABEL_COL])
        thr = self.best_f1_threshold(va[LABEL_COL], model.predict_proba(X(va))[:, 1])   # tuned on VAL only
        m: dict[str, float] = {}
        for split, d in (("val", va), ("test", te)):
            for k, v in self.score(d[LABEL_COL], model.predict_proba(X(d))[:, 1], thr).items():
                m[f"{split}_{k}"] = float(v)
        # heuristic baseline: -smoothed divergence alone (what an oceanographer would try first)
        m["test_baseline_pr_auc"] = float(average_precision_score(te[LABEL_COL], -te["div_smooth"]))
        m["test_baseline_roc_auc"] = float(roc_auc_score(te[LABEL_COL], -te["div_smooth"]))
        m["test_pr_auc_gain_vs_baseline"] = m["test_pr_auc"] - m["test_baseline_pr_auc"]
        imp = self._perm_importance(model, X(va), va[LABEL_COL], "roc_auc")
        return TrainResult(model, {**self.params(), "decision_threshold": round(thr, 4),
                                   "positive_rate_train": float(tr[LABEL_COL].mean())},
                           m, self.feature_cols, imp, thr)

    def evaluate_bundle(self, model, threshold: float, test: pd.DataFrame) -> dict:
        """Score an already-trained (champion) model on a new test set for champion/challenger comparison."""
        p = model.predict_proba(test[self.feature_cols])[:, 1]
        return {k: float(v) for k, v in self.score(test[LABEL_COL], p, threshold).items()}


class DriftForecaster(BaseTrainer):
    """One-step-ahead surface-current (u, v) forecaster used for micro-debris drift."""
    name = "current_drift_forecaster"
    primary_metric = "test_rmse_mean"
    higher_is_better = False

    def build_model(self):
        return MultiOutputRegressor(HistGradientBoostingRegressor(
            max_iter=self.cfg.max_iter, learning_rate=self.cfg.learning_rate,
            max_depth=self.cfg.max_depth, random_state=self.cfg.seed))

    def _fit_eval(self, tr, va, te) -> TrainResult:
        clean = lambda d: d.dropna(subset=TARGET_UV)
        tr, va, te = clean(tr), clean(va), clean(te)
        model = self.build_model().fit(tr[self.feature_cols], tr[TARGET_UV])
        m: dict[str, float] = {}
        for split, d in (("val", va), ("test", te)):
            pred = model.predict(d[self.feature_cols])
            rm = [float(np.sqrt(mean_squared_error(d[t], pred[:, i]))) for i, t in enumerate(TARGET_UV)]
            m[f"{split}_rmse_u"], m[f"{split}_rmse_v"] = rm
            m[f"{split}_rmse_mean"] = float(np.mean(rm))
            m[f"{split}_r2"] = float(r2_score(d[TARGET_UV], pred))
        persist = [float(np.sqrt(mean_squared_error(te[t], te[s]))) for t, s in (("u_next", "u"), ("v_next", "v"))]
        m["test_persistence_rmse_mean"] = float(np.mean(persist))
        m["test_rmse_gain_vs_persistence"] = m["test_persistence_rmse_mean"] - m["test_rmse_mean"]
        scorer = lambda est, X, y: -float(np.sqrt(mean_squared_error(y, est.predict(X))))
        Xv = va[self.feature_cols]
        Xs = Xv.sample(min(len(Xv), 2000), random_state=self.cfg.seed)
        r = permutation_importance(model, Xs, va.loc[Xs.index, TARGET_UV], n_repeats=2,
                                   random_state=self.cfg.seed, scoring=scorer)
        imp = dict(sorted(zip(self.feature_cols, r.importances_mean.round(6)), key=lambda kv: -kv[1]))
        return TrainResult(model, self.params(), m, self.feature_cols, imp)
