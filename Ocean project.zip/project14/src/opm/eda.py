"""Phase 1 - exploratory data analysis. Writes figures + a JSON summary to reports/eda."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .config import BAND_CENTERS, BAND_COLS, Config
from .processing import FEATURE_COLS, LABEL_COL


class EDAReport:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.out = Path(cfg.reports_dir) / "eda"
        self.out.mkdir(parents=True, exist_ok=True)

    def run(self, raw: pd.DataFrame, feats: pd.DataFrame) -> dict:
        summary = self._summary(raw, feats)
        self._spectrum(feats)
        self._spatial(feats)
        self._correlations(feats)
        self._distributions(feats)
        self._timeseries(feats)
        (self.out / "eda_summary.json").write_text(json.dumps(summary, indent=2, default=float))
        return summary

    # ------------------------------------------------------------------
    def _summary(self, raw, feats) -> dict:
        y = feats[LABEL_COL]
        corr = feats[FEATURE_COLS].corrwith(y).sort_values(key=np.abs, ascending=False)
        return {
            "rows_raw": int(len(raw)), "rows_clean": int(len(feats)),
            "days": int(feats["day"].nunique()), "cells": int(feats["cell_id"].nunique()),
            "duplicates_removed": int(len(raw) - len(raw.drop_duplicates(["day", "cell_id"]))),
            "missing_band_values_raw": {c: int(raw[c].isna().sum()) for c in BAND_COLS},
            "convergence_positive_rate": float(y.mean()),
            "speed_mean_ms": float(feats["speed"].mean()),
            "top_label_correlations": {k: round(float(v), 3) for k, v in corr.head(8).items()},
            "note": "Strong |corr| with div_smooth + hiss_* supports both physical and acoustic signal; "
                    "class imbalance means PR-AUC, not accuracy, is the headline metric.",
        }

    def _spectrum(self, f):
        fig, ax = plt.subplots(figsize=(6, 4))
        for lab, name in ((0, "no convergence"), (1, "convergence zone")):
            m = f.loc[f[LABEL_COL] == lab, BAND_COLS].mean()
            ax.plot(BAND_CENTERS, m.values, marker="o", label=name)
        ax.set(xlabel="frequency (kHz)", ylabel="mean level (dB)", title="Hydroacoustic hiss spectrum by class")
        ax.legend(); fig.tight_layout(); fig.savefig(self.out / "spectrum_by_class.png", dpi=130); plt.close(fig)

    def _spatial(self, f):
        nx, ny = self.cfg.grid_nx, self.cfg.grid_ny
        piv = lambda col: f.groupby("cell_id")[col].mean().reindex(range(nx * ny)).to_numpy().reshape(ny, nx)
        fig, axs = plt.subplots(1, 3, figsize=(14, 4))
        for ax, (col, title, cmap) in zip(axs, [(LABEL_COL, "Convergence frequency", "magma"),
                                                 ("div_smooth", "Mean divergence (1/s, rel.)", "coolwarm"),
                                                 ("hiss_total", "Mean broadband hiss (dB)", "viridis")]):
            im = ax.imshow(piv(col), origin="lower", cmap=cmap, extent=(-1, 1, -1, 1)); ax.set_title(title)
            fig.colorbar(im, ax=ax, shrink=0.8)
        U = piv("u")[::2, ::2]; V = piv("v")[::2, ::2]
        xs = np.linspace(-1, 1, nx)[::2]; ys = np.linspace(-1, 1, ny)[::2]
        axs[1].quiver(xs, ys, U, V, color="k", alpha=0.6)
        fig.tight_layout(); fig.savefig(self.out / "spatial_maps.png", dpi=130); plt.close(fig)

    def _correlations(self, f):
        cols = [c for c in FEATURE_COLS if c not in BAND_COLS[1:-1]] + [LABEL_COL]
        c = f[cols].corr().to_numpy()
        fig, ax = plt.subplots(figsize=(9, 8))
        im = ax.imshow(c, cmap="coolwarm", vmin=-1, vmax=1)
        ax.set_xticks(range(len(cols))); ax.set_xticklabels(cols, rotation=90, fontsize=7)
        ax.set_yticks(range(len(cols))); ax.set_yticklabels(cols, fontsize=7)
        fig.colorbar(im, shrink=0.8); ax.set_title("Feature correlation"); fig.tight_layout()
        fig.savefig(self.out / "correlation.png", dpi=130); plt.close(fig)

    def _distributions(self, f):
        cols = ["speed", "div_smooth", "vort", "hiss_total", "hiss_slope", "spectral_centroid"]
        fig, axs = plt.subplots(2, 3, figsize=(12, 6))
        for ax, c in zip(axs.ravel(), cols):
            for lab in (0, 1):
                ax.hist(f.loc[f[LABEL_COL] == lab, c].dropna(), bins=40, alpha=0.55, density=True, label=str(lab))
            ax.set_title(c)
        axs[0, 0].legend(title="class"); fig.tight_layout()
        fig.savefig(self.out / "distributions.png", dpi=130); plt.close(fig)

    def _timeseries(self, f):
        g = f.groupby("day").agg(rate=(LABEL_COL, "mean"), hiss=("hiss_total", "mean"), speed=("speed", "mean"))
        fig, ax = plt.subplots(figsize=(9, 3.5))
        ax.plot(g.index, g["rate"], label="convergence rate"); ax.set_xlabel("day"); ax.set_ylabel("rate")
        ax2 = ax.twinx(); ax2.plot(g.index, g["hiss"], color="tab:red", alpha=0.6, label="mean hiss dB")
        ax.set_title("Daily convergence rate vs broadband hiss"); fig.tight_layout()
        fig.savefig(self.out / "timeseries.png", dpi=130); plt.close(fig)
