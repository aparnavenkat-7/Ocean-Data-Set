"""Central configuration. Override any field via Config(...) or env vars."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

# Hydroacoustic micro-plastic friction "hiss" band edges (kHz)
HYDRO_BANDS: list[tuple[int, int]] = [(20, 25), (25, 30), (30, 35), (35, 40), (40, 45), (45, 50)]
BAND_COLS: list[str] = [f"band_{lo}_{hi}" for lo, hi in HYDRO_BANDS]
BAND_CENTERS: list[float] = [(lo + hi) / 2 for lo, hi in HYDRO_BANDS]


@dataclass
class Config:
    # ---- paths
    root: Path = ROOT
    data_dir: Path = ROOT / "data"
    reports_dir: Path = ROOT / "reports"
    models_dir: Path = ROOT / "models"
    alerts_dir: Path = ROOT / "alerts"

    # ---- simulation / grid
    seed: int = 42
    grid_nx: int = 20
    grid_ny: int = 20
    n_days: int = 90                 # reference (training) period
    convergence_threshold: float = 0.35   # latent plastic density above which a cell is a convergence zone

    # ---- splitting (by time, never random)
    train_frac: float = 0.6
    val_frac: float = 0.2            # remainder is test

    # ---- model
    max_iter: int = 250
    learning_rate: float = 0.08
    max_depth: int = 6

    # ---- drift monitoring
    psi_warn: float = 0.10
    psi_alert: float = 0.25
    drift_feature_share: float = 0.20   # share of features in alert state that triggers overall drift
    perf_drop_alert: float = 0.05       # ROC-AUC drop vs reference that flags concept drift
    auto_retrain: bool = True

    # ---- mlflow
    experiment_name: str = "project14-ocean-plastic"
    tracking_uri: str = field(default_factory=lambda: os.getenv(
        "MLFLOW_TRACKING_URI", f"sqlite:///{(ROOT / 'mlflow.db').as_posix()}"))
    artifact_uri: str = field(default_factory=lambda: (ROOT / "mlartifacts").as_uri())
    classifier_name: str = "convergence-zone-classifier"
    forecaster_name: str = "current-drift-forecaster"

    # ---- alerting (optional Slack-style webhook)
    alert_webhook_url: str | None = field(default_factory=lambda: os.getenv("ALERT_WEBHOOK_URL"))

    def ensure_dirs(self) -> None:
        for d in (self.data_dir, self.reports_dir, self.models_dir, self.alerts_dir):
            Path(d).mkdir(parents=True, exist_ok=True)
