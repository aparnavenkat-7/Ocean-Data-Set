"""Project 14 - Hydroacoustic Ocean-Plastic Gyre Convergence & Current Drift Modeler (SDG 14)."""
__version__ = "1.0.0"
