"""Alert fan-out: structured log, JSONL audit trail, optional Slack-compatible webhook."""
from __future__ import annotations

import json
import logging
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from .config import Config
from .drift import DriftReport

log = logging.getLogger("opm.alerts")


class AlertManager:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.path = Path(cfg.alerts_dir) / "alerts.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def format(self, r: DriftReport, batch_label: str) -> str:
        top = ", ".join(f"{f['feature']} (PSI {f['psi']:.2f})" for f in r.top(4))
        lines = [f"[Project14] DRIFT {r.severity.upper()} on {batch_label}", *[f" - {x}" for x in r.reasons],
                 f" - top drifted features: {top}"]
        if r.cur_auc is not None:
            lines.append(f" - ROC-AUC {r.cur_auc:.3f} vs reference {r.ref_auc:.3f}")
        return "\n".join(lines)

    def send(self, r: DriftReport, batch_label: str) -> bool:
        if r.severity == "ok":
            return False
        msg = self.format(r, batch_label)
        (log.error if r.drift_detected else log.warning)(msg)
        rec = {"ts": datetime.now(timezone.utc).isoformat(), "batch": batch_label, "severity": r.severity,
               "reasons": r.reasons, "top_features": r.top(5), "prediction_psi": r.prediction_psi,
               "auc_drop": r.auc_drop}
        with self.path.open("a") as fh:
            fh.write(json.dumps(rec, default=float) + "\n")
        if self.cfg.alert_webhook_url and r.drift_detected:
            try:
                req = urllib.request.Request(self.cfg.alert_webhook_url, data=json.dumps({"text": msg}).encode(),
                                             headers={"Content-Type": "application/json"})
                urllib.request.urlopen(req, timeout=5)
            except Exception as e:  # alerting must never crash the pipeline
                log.warning("webhook delivery failed: %s", e)
        return True
