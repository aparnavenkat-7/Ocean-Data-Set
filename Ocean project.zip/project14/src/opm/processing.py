"""Phase 1 - data validation, cleaning and physics-aware feature engineering."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.ndimage import uniform_filter

from .config import BAND_CENTERS, BAND_COLS, Config

log = logging.getLogger(__name__)

REQUIRED_COLUMNS = ["day", "cell_id", "u", "v", *BAND_COLS]
LABEL_COL = "convergence_zone"
LEAKY_COLS = ["plastic_density", LABEL_COL, "u_next", "v_next"]   # never allowed as features
TARGET_UV = ["u_next", "v_next"]

FEATURE_COLS = [
    "u", "v", "speed", "dir_sin", "dir_cos", "div", "vort", "div_smooth",
    *BAND_COLS, "hiss_total", "hiss_slope", "hiss_hi_lo", "spectral_centroid",
    "hiss_total_lag1", "hiss_total_roll3", "div_smooth_lag1",
]


@dataclass
class DataProcessor:
    """Fit/transform processor. `fit` learns robust bounds + fill values from TRAIN data only."""
    cfg: Config
    band_bounds_: dict[str, tuple[float, float]] = field(default_factory=dict)
    fill_values_: dict[str, float] = field(default_factory=dict)
    is_fitted_: bool = False

    # ------------------------------------------------------------------ validation
    def validate(self, df: pd.DataFrame) -> None:
        missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
        if missing:
            raise ValueError(f"Raw data missing required columns: {missing}")
        if df[["u", "v"]].abs().max().max() > 10:
            raise ValueError("Current magnitude > 10 m/s: units look wrong")

    # ------------------------------------------------------------------ fit
    def fit(self, raw_train: pd.DataFrame) -> "DataProcessor":
        self.validate(raw_train)
        for c in BAND_COLS:
            x = raw_train[c].dropna()
            med = x.median()
            mad = 1.4826 * (x - med).abs().median()
            self.band_bounds_[c] = (med - 6 * mad, med + 6 * mad)
            self.fill_values_[c] = float(med)
        for c in ("u", "v"):
            self.fill_values_[c] = float(raw_train[c].median())
        self.is_fitted_ = True
        return self

    # ------------------------------------------------------------------ clean
    def clean(self, raw: pd.DataFrame) -> pd.DataFrame:
        df = raw.drop_duplicates(subset=["day", "cell_id"], keep="first").copy()
        n_spike = 0
        for c in BAND_COLS:
            lo, hi = self.band_bounds_[c]
            bad = (df[c] < lo) | (df[c] > hi)
            n_spike += int(bad.sum())
            df.loc[bad, c] = np.nan
        n_nan = int(df[BAND_COLS].isna().sum().sum())
        # impute: previous valid reading of the same cell, then train median
        df = df.sort_values(["cell_id", "day"])
        df[BAND_COLS] = df.groupby("cell_id")[BAND_COLS].transform(lambda s: s.ffill())
        for c in BAND_COLS:
            df[c] = df[c].fillna(self.fill_values_[c])
        for c in ("u", "v"):
            df[c] = df[c].fillna(self.fill_values_[c])
        log.info("clean: dropped %d duplicates, masked %d spikes, imputed %d missing band values",
                 len(raw) - df.shape[0], n_spike, n_nan)
        return df.sort_values(["day", "cell_id"]).reset_index(drop=True)

    # ------------------------------------------------------------------ features
    def _grid_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Divergence / vorticity from the U/V field. Requires a complete (day x ny x nx) grid."""
        nx, ny = self.cfg.grid_nx, self.cfg.grid_ny
        days = np.sort(df["day"].unique())
        full = pd.MultiIndex.from_product([days, np.arange(nx * ny)], names=["day", "cell_id"])
        d = df.set_index(["day", "cell_id"]).reindex(full)
        U = d["u"].to_numpy().reshape(len(days), ny, nx)
        V = d["v"].to_numpy().reshape(len(days), ny, nx)
        U = np.where(np.isnan(U), np.nanmean(U), U)
        V = np.where(np.isnan(V), np.nanmean(V), V)
        h = 2.0 / (nx - 1)
        div = np.gradient(U, h, axis=2) + np.gradient(V, h, axis=1)
        vort = np.gradient(V, h, axis=2) - np.gradient(U, h, axis=1)
        div_s = uniform_filter(div, size=(1, 3, 3), mode="nearest")
        out = pd.DataFrame({"day": np.repeat(days, nx * ny), "cell_id": np.tile(np.arange(nx * ny), len(days)),
                            "div": div.ravel(), "vort": vort.ravel(), "div_smooth": div_s.ravel()})
        return df.merge(out, on=["day", "cell_id"], how="left")

    def transform(self, raw: pd.DataFrame, with_targets: bool = True) -> pd.DataFrame:
        if not self.is_fitted_:
            raise RuntimeError("DataProcessor.fit must be called before transform")
        self.validate(raw)
        df = self._grid_features(self.clean(raw))

        df["speed"] = np.hypot(df["u"], df["v"])
        ang = np.arctan2(df["v"], df["u"])
        df["dir_sin"], df["dir_cos"] = np.sin(ang), np.cos(ang)

        B = df[BAND_COLS].to_numpy()
        power = 10 ** (B / 10)
        df["hiss_total"] = 10 * np.log10(power.mean(axis=1))
        centers = np.array(BAND_CENTERS)
        df["hiss_slope"] = np.polyfit(centers, B.T, 1)[0]                     # dB per kHz
        df["hiss_hi_lo"] = B[:, -3:].mean(axis=1) - B[:, :3].mean(axis=1)
        df["spectral_centroid"] = (power * centers).sum(axis=1) / power.sum(axis=1)

        df = df.sort_values(["cell_id", "day"])
        g = df.groupby("cell_id")
        df["hiss_total_lag1"] = g["hiss_total"].shift(1)
        df["hiss_total_roll3"] = g["hiss_total"].transform(lambda s: s.rolling(3, min_periods=1).mean())
        df["div_smooth_lag1"] = g["div_smooth"].shift(1)
        if with_targets:
            df["u_next"] = g["u"].shift(-1)
            df["v_next"] = g["v"].shift(-1)
        df = df.sort_values(["day", "cell_id"]).reset_index(drop=True)

        assert not set(FEATURE_COLS) & set(LEAKY_COLS), "leakage guard tripped"
        return df

    # ------------------------------------------------------------------ splitting
    def time_split(self, df: pd.DataFrame, recent_start_day: int | None = None
                   ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Chronological split. If `recent_start_day` is given (retraining after drift), the recent regime is
        split 60/20/20 by time and its train part is appended to ALL earlier data, so val/test come from the
        new regime while nothing from the future leaks into training."""
        if recent_start_day is None:
            days = np.sort(df["day"].unique())
            n_tr = int(len(days) * self.cfg.train_frac)
            n_va = int(len(days) * self.cfg.val_frac)
            tr_d, va_d, te_d = days[:n_tr], days[n_tr:n_tr + n_va], days[n_tr + n_va:]
        else:
            old = np.sort(df.loc[df["day"] < recent_start_day, "day"].unique())
            new = np.sort(df.loc[df["day"] >= recent_start_day, "day"].unique())
            n_tr = max(int(len(new) * self.cfg.train_frac), 1)
            n_va = max(int(len(new) * self.cfg.val_frac), 1)
            tr_d, va_d, te_d = np.concatenate([old, new[:n_tr]]), new[n_tr:n_tr + n_va], new[n_tr + n_va:]
        return (df[df["day"].isin(tr_d)].copy(), df[df["day"].isin(va_d)].copy(), df[df["day"].isin(te_d)].copy())

    def train_days(self, raw: pd.DataFrame) -> pd.DataFrame:
        days = np.sort(raw["day"].unique())
        n_tr = int(len(days) * self.cfg.train_frac)
        return raw[raw["day"].isin(days[:n_tr])]
