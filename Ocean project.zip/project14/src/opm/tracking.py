"""MLflow wrapper: experiment setup, run logging, model registry + champion alias."""
from __future__ import annotations

import json
import logging
import tempfile
from contextlib import contextmanager
from pathlib import Path

import mlflow
import mlflow.sklearn
from mlflow.tracking import MlflowClient

from .config import Config
from .drift import DriftReport
from .trainer import BaseTrainer, TrainResult

log = logging.getLogger(__name__)


# Types skops must trust to (de)serialise HistGradientBoosting models. These are artifacts this pipeline
# trains and logs itself; do NOT widen this list to load models from untrusted sources.
TRUSTED_SKOPS_TYPES = ["sklearn.ensemble._hist_gradient_boosting.predictor.TreePredictor"]


class Tracker:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        mlflow.set_tracking_uri(cfg.tracking_uri)
        if mlflow.get_experiment_by_name(cfg.experiment_name) is None:
            mlflow.create_experiment(cfg.experiment_name, artifact_location=cfg.artifact_uri)
        mlflow.set_experiment(cfg.experiment_name)
        self.client = MlflowClient()

    @contextmanager
    def run(self, name: str, tags: dict | None = None):
        with mlflow.start_run(run_name=name, tags=tags or {}) as r:
            yield r

    def log_dict(self, obj: dict, filename: str, folder: str | None = None) -> None:
        mlflow.log_dict(json.loads(json.dumps(obj, default=float)), f"{folder}/{filename}" if folder else filename)

    def log_training(self, trainer: BaseTrainer, res: TrainResult, registered_name: str, X_example) -> str | None:
        """Logs inside the *current* run. Returns registered model version."""
        mlflow.log_params(res.params)
        mlflow.log_metrics(res.metrics)
        self.log_dict(res.importances, "permutation_importance.json")
        info = mlflow.sklearn.log_model(res.model, name="model", input_example=X_example.head(5),
                                        registered_model_name=registered_name,
                                        skops_trusted_types=TRUSTED_SKOPS_TYPES)
        return getattr(info, "registered_model_version", None)

    def champion_metric(self, registered_name: str, metric: str) -> float | None:
        try:
            mv = self.client.get_model_version_by_alias(registered_name, "champion")
            return self.client.get_run(mv.run_id).data.metrics.get(metric)
        except Exception:
            return None

    def promote(self, registered_name: str, version: str | None) -> None:
        if version is not None:
            self.client.set_registered_model_alias(registered_name, "champion", str(version))
            log.info("promoted %s v%s -> champion", registered_name, version)

    def log_drift(self, report: DriftReport, batch_label: str) -> None:
        mlflow.log_metrics({"n_alert_features": report.n_alert, "alert_share": report.alert_share,
                            **({"prediction_psi": report.prediction_psi} if report.prediction_psi is not None else {}),
                            **({"auc_drop": report.auc_drop} if report.auc_drop is not None else {}),
                            "drift_detected": float(report.drift_detected)})
        mlflow.set_tags({"drift_severity": report.severity, "batch": batch_label})
        self.log_dict(report.to_dict(), "drift_report.json")
