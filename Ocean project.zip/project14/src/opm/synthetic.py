"""Physically-motivated synthetic data so the whole stack runs without the field dataset.

Surface currents = rotating gyre + inward Ekman-like term (creates negative divergence at the
gyre core) + mean drift. Micro-plastic accumulates (with lag) where divergence is negative.
Hydroacoustic hiss in 20-50 kHz rises with plastic density, more strongly at higher frequencies.
Sensor dropouts, spikes and duplicates are injected so the cleaning stage has real work to do.

Replace `generate_dataset` with your real loader; keep the column contract in `RAW_COLUMNS`.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import BAND_CENTERS, BAND_COLS, Config

RAW_COLUMNS = ["time", "day", "cell_id", "x", "y", "u", "v", *BAND_COLS, "plastic_density", "convergence_zone"]


def generate_dataset(cfg: Config, start_day: int = 0, n_days: int | None = None,
                     simulate_drift: bool = False, seed: int | None = None) -> pd.DataFrame:
    n_days = n_days or cfg.n_days
    rng = np.random.default_rng((seed if seed is not None else cfg.seed) + start_day)
    nx, ny = cfg.grid_nx, cfg.grid_ny
    xs, ys = np.linspace(-1, 1, nx), np.linspace(-1, 1, ny)
    X, Y = np.meshgrid(xs, ys)                      # shape (ny, nx)
    dx, dy = xs[1] - xs[0], ys[1] - ys[0]

    days = np.arange(start_day, start_day + n_days)
    prev_dens = np.zeros((ny, nx))
    frames = []
    centers = np.array(BAND_CENTERS)
    gain = 4.0 + 0.45 * (centers - 20.0)             # dB response per unit density, grows with frequency

    for d in days:
        cx, cy = 0.10 * np.sin(2 * np.pi * d / 30), 0.10 * np.cos(2 * np.pi * d / 45)
        ddx, ddy = X - cx, Y - cy
        r2 = ddx**2 + ddy**2
        rot = 0.8 * np.exp(-r2 / (2 * 0.5**2))
        inward = -0.6 * np.exp(-r2 / (2 * 0.3**2))
        u_true = -ddy * rot + inward * ddx + 0.10
        v_true = ddx * rot + inward * ddy + 0.05
        div_true = np.gradient(u_true, dx, axis=1) + np.gradient(v_true, dy, axis=0)

        # plastic accumulates with memory where flow converges
        inst = np.clip(-div_true, 0, None)
        dens = 0.7 * prev_dens + 0.3 * inst * 1.6
        prev_dens = dens

        speed_scale = 1.3 if simulate_drift else 1.0
        u = speed_scale * u_true + rng.normal(0, 0.06, u_true.shape) + (0.08 if simulate_drift else 0.0)
        v = speed_scale * v_true + rng.normal(0, 0.06, v_true.shape)

        ambient = 58.0 - 0.25 * (centers - 20.0)     # shipping/wind noise falls with frequency
        bands = ambient[None, None, :] + gain[None, None, :] * dens[..., None]
        bands = bands + rng.normal(0, 7.0 if not simulate_drift else 8.5, bands.shape)
        if simulate_drift:                           # new hydrophone gain / biofouling at high freq
            bands[..., centers >= 35] += 4.0

        frame = pd.DataFrame({
            "time": pd.Timestamp("2026-01-01") + pd.to_timedelta(int(d), unit="D"),
            "day": int(d),
            "cell_id": np.arange(nx * ny),
            "x": X.ravel(), "y": Y.ravel(),
            "u": u.ravel(), "v": v.ravel(),
            "plastic_density": dens.ravel(),
        })
        for i, c in enumerate(BAND_COLS):
            frame[c] = bands[..., i].ravel()
        frames.append(frame)

    df = pd.concat(frames, ignore_index=True)
    df["convergence_zone"] = (df["plastic_density"] > cfg.convergence_threshold).astype(int)

    # ---- inject realistic faults
    n = len(df)
    for c in BAND_COLS:
        df.loc[rng.random(n) < 0.015, c] = np.nan                      # dropouts
        spikes = rng.random(n) < 0.003
        df.loc[spikes, c] += 30.0                                       # transients (ship passes, snapping shrimp)
    dups = df.sample(frac=0.002, random_state=int(rng.integers(1_000_000)))
    df = pd.concat([df, dups], ignore_index=True)
    return df[RAW_COLUMNS].sort_values(["day", "cell_id"]).reset_index(drop=True)
