"""Shared Streamlit helpers: layout, charts, navigation state, verify-then-proceed gate."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

PALETTE = ["#0b7285", "#f08c00", "#2f9e44", "#c92a2a", "#6741d9", "#1971c2", "#e64980", "#5c940d"]
STEPS = [("Upload & Introduction", "📥", "Unit 1"), ("Data Cleaning", "🧹", "Unit 1"),
         ("Exploratory Data Analysis", "🔎", "Unit 2"), ("Descriptive Analytics", "📊", "Unit 3"),
         ("Diagnostic Analytics", "🧪", "Unit 4"), ("Predictive Analytics", "🤖", "Unit 5"),
         ("Report & Monitoring", "📄", "Wrap-up")]
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "axes.prop_cycle": plt.cycler(color=PALETTE),
                     "figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.25})


# ------------------------------------------------------------------ small wrappers
def _arrow_safe(df):
    """Columns mixing numbers and text (e.g. a corrupted numeric field) cannot be serialised by Arrow -> show as text."""
    if not isinstance(df, pd.DataFrame):
        return df
    d = df.copy()
    for c in d.columns:
        if d[c].dtype == object and str(pd.api.types.infer_dtype(d[c], skipna=True)).startswith("mixed"):
            d[c] = d[c].map(lambda v: v if pd.isna(v) else str(v))
    return d


def show_df(df, height=None, **kw):
    df = _arrow_safe(df)
    if height is not None:
        kw["height"] = height
    try:
        st.dataframe(df, width="stretch", **kw)
    except TypeError:                          # older Streamlit
        st.dataframe(df, use_container_width=True, **kw)


def btn(label, **kw):
    try:
        return st.button(label, width="stretch", **kw)
    except TypeError:
        return st.button(label, use_container_width=True, **kw)


def fig(w=6.0, h=3.6, **kw):
    return plt.subplots(figsize=(w, h), **kw)


def boxplot(ax, data, horizontal=False, **kw):
    """matplotlib >= 3.10 prefers orientation=; older versions only know vert=. Support both."""
    try:
        return ax.boxplot(data, orientation="horizontal" if horizontal else "vertical", **kw)
    except TypeError:
        return ax.boxplot(data, vert=not horizontal, **kw)


def show_fig(f):
    st.pyplot(f, clear_figure=True)
    plt.close(f)


def concept(title: str, body: str, expanded: bool = False):
    with st.expander(f"📘 Syllabus concept - {title}", expanded=expanded):
        st.markdown(body)


def verdict(ok: bool, text: str):
    (st.success if ok else st.warning)(text)


# ------------------------------------------------------------------ session state
def init_state():
    ss = st.session_state
    ss.setdefault("step", 0)
    ss.setdefault("data", {})        # step index -> DataFrame produced by that step (0 raw, 1 cleaned, 2 outlier-treated)
    ss.setdefault("pending", {})     # what the page currently on screen would pass forward
    ss.setdefault("done", set())
    ss.setdefault("findings", {})    # step -> {key: text} shown in the final report
    ss.setdefault("dataset_name", "")
    for k in list(ss.keys()):        # keep widget values alive while their page is not on screen
        if isinstance(k, str) and k.startswith("w_"):
            try:
                ss[k] = ss[k]
            except Exception:        # read-only widgets (buttons) cannot be re-assigned; they hold no state worth keeping
                pass


def get_input(step: int) -> pd.DataFrame | None:
    """Latest dataset available to a page: step 1 reads raw, step 2 reads cleaned, steps >= 3 read outlier-treated."""
    d = st.session_state.data
    return d.get(min(step - 1, 2))


def record(step: int, key: str, text: str):
    st.session_state.findings.setdefault(step, {})[key] = text


def goto(i: int):
    st.session_state.step = i


def complete(i: int):
    ss = st.session_state
    new = ss.pending.get(i)
    if new is not None:
        old = ss.data.get(i)
        changed = old is None or not old.equals(new)
        ss.data[i] = new
        if changed:                                   # downstream results are stale -> redo them
            ss.data = {k: v for k, v in ss.data.items() if k <= i}
            ss.done = set(range(i))
            if i == 0:
                for k in [k for k in ss.keys() if isinstance(k, str) and k.startswith("w_") and k not in ("w_src", "w_upload")]:
                    del ss[k]
                ss.findings = {}
    ss.done.add(i)
    ss.step = min(i + 1, len(STEPS) - 1)


def proceed_bar(i: int, can_proceed: bool = True, hint: str = ""):
    st.divider()
    c1, c2, c3 = st.columns([1, 2.2, 1.4])
    with c1:
        if i > 0:
            btn("◀ Back", key=f"back_{i}", on_click=goto, args=(i - 1,))
    with c2:
        verified = st.checkbox("I have verified this step's output", key=f"verify_{i}", disabled=not can_proceed)
        if hint and not can_proceed:
            st.caption(hint)
    with c3:
        if i < len(STEPS) - 1:
            btn(f"Proceed to step {i + 2}: {STEPS[i + 1][0]} ▶", key=f"proceed_{i}", type="primary",
                disabled=not (verified and can_proceed), on_click=complete, args=(i,))
        else:
            st.success("Pipeline complete 🎉")


def page_header(i: int, subtitle: str):
    name, icon, unit = STEPS[i]
    st.markdown(f"### {icon} Step {i + 1} of {len(STEPS)} · {name}")
    st.caption(f"{unit} · {subtitle}")
