"""Pure analytics functions (no Streamlit) - every syllabus step is implemented here and unit-tested."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.impute import KNNImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, mean_absolute_error, mean_squared_error,
                             precision_score, r2_score, recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import SVC

MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "--", "-", "?", "??", "error", "err", "missing", "#n/a", "#value!"}
KNN_ROW_LIMIT = 5000


def is_numeric(s: pd.Series) -> bool:
    return pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s)


def is_id_like(name: str, s: pd.Series | None = None) -> bool:
    """Identifier columns (cell_id, row_index ...) carry no analytical meaning; keep them out of default selections."""
    raw, n = str(name), str(name).lower()
    if n in ("id", "index", "idx", "serial", "sno") or n.endswith("_id") or n.startswith("id_") or "_id_" in n \
            or (raw.endswith("ID") and len(raw) > 2) or n.endswith(" id"):
        return True
    return bool(s is not None and len(s) > 20 and s.nunique() == len(s) and pd.api.types.is_integer_dtype(s))


def default_numeric(df: pd.DataFrame, cols: list[str], k: int = 10) -> list[str]:
    """First k columns that are not identifiers (falls back to all if everything looks like an id)."""
    keep = [c for c in cols if not is_id_like(c, df[c])]
    return (keep or list(cols))[:k]


# ============================================================ UNIT 1 - types, quality, cleaning, imputation
def standardize_missing_tokens(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in out.select_dtypes(include=["object", "string"]).columns:
        m = out[c].astype("string").str.strip().str.lower().isin(MISSING_TOKENS).fillna(False).to_numpy(dtype=bool)
        out.loc[m, c] = np.nan
    return out


def detect_corrupted(df: pd.DataFrame) -> pd.DataFrame:
    """Text columns that are mostly numbers but contain unparseable strings (a corrupted numeric column)."""
    rows = []
    for c in df.select_dtypes(include=["object", "string"]).columns:
        s = df[c].dropna()
        if s.empty:
            continue
        parsed = pd.to_numeric(s, errors="coerce")
        frac = parsed.notna().mean()
        if 0.7 <= frac < 1.0:
            bad = s[parsed.isna()].astype(str)
            rows.append({"column": c, "numeric_values": int(parsed.notna().sum()), "non_numeric_values": int(parsed.isna().sum()),
                         "examples": ", ".join(bad.value_counts().head(4).index)})
    return pd.DataFrame(rows, columns=["column", "numeric_values", "non_numeric_values", "examples"])


def classify_columns(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in df.columns:
        s = df[c]
        nun = int(s.nunique(dropna=True))
        if pd.api.types.is_bool_dtype(s):
            kind = "Qualitative - binary"
        elif pd.api.types.is_datetime64_any_dtype(s):
            kind = "Temporal"
        elif is_numeric(s):
            nn = s.dropna()
            is_int = bool(len(nn)) and bool((nn == np.floor(nn)).all())
            kind = "Qualitative - binary (coded 0/1)" if (is_int and nun == 2) else (
                "Quantitative - discrete" if is_int else "Quantitative - continuous")
        else:
            parsed = pd.to_numeric(s.dropna(), errors="coerce")
            if len(parsed) and parsed.notna().mean() >= 0.7:
                kind = "Quantitative - stored as text (corrupted)"
            elif nun <= 2:
                kind = "Qualitative - binary"
            elif nun <= 20:
                kind = "Qualitative - nominal"
            else:
                kind = "Qualitative - text / high-cardinality"
        rows.append({"column": c, "pandas dtype": str(s.dtype), "data type": kind, "unique": nun,
                     "missing": int(standardize_missing_tokens(df[[c]]).iloc[:, 0].isna().sum()),
                     "example": str(s.dropna().iloc[0]) if s.notna().any() else ""})
    return pd.DataFrame(rows)


def quality_report(df: pd.DataFrame) -> dict:
    tmp = standardize_missing_tokens(df)
    miss = tmp.isna().sum()
    return {"rows": len(df), "cols": df.shape[1], "missing_cells": int(miss.sum()),
            "missing_pct": float(miss.sum() / max(df.size, 1) * 100),
            "missing_by_col": (miss / max(len(df), 1) * 100).round(2),
            "duplicate_rows": int(df.duplicated().sum()),
            "constant_cols": [c for c in df.columns if df[c].nunique(dropna=True) <= 1],
            "corrupted": detect_corrupted(df)}


@dataclass
class CleanConfig:
    fix_corrupted: bool = True
    standardize_tokens: bool = True
    drop_duplicates: bool = True
    drop_cols: list = field(default_factory=list)
    col_missing_thresh: float = 50.0          # drop columns with MORE than this % missing (100 = off)
    row_missing_max: int | None = None        # drop rows with MORE than this many missing cells (None = off)
    num_strategy: str = "median"              # mean | median | knn | constant | none
    cat_strategy: str = "mode"                # mode | unknown | none
    constant_value: float = 0.0


def clean_dataframe(df: pd.DataFrame, cfg: CleanConfig) -> tuple[pd.DataFrame, list[dict]]:
    out, log = df.copy(), []

    def add(action: str, detail: str):
        log.append({"#": len(log) + 1, "action": action, "detail": detail, "rows": len(out), "cols": out.shape[1]})

    if cfg.fix_corrupted:
        for _, r in detect_corrupted(out).iterrows():
            c, before = r["column"], int(out[r["column"]].isna().sum())
            out[c] = pd.to_numeric(out[c], errors="coerce")
            add("Fix corrupted values", f"'{c}': text -> number; {int(out[c].isna().sum()) - before} unparseable entries "
                                        f"became missing (e.g. {r['examples']})")
    if cfg.standardize_tokens:
        n = 0
        for c in out.select_dtypes(include=["object", "string"]).columns:
            m = out[c].astype("string").str.strip().str.lower().isin(MISSING_TOKENS).fillna(False).to_numpy(dtype=bool)
            n += int(m.sum())
            out.loc[m, c] = np.nan
        add("Standardise placeholders", f"{n} placeholder tokens (N/A, --, ?, null ...) in text columns -> true missing")
    if cfg.drop_duplicates:
        b = len(out)
        out = out.drop_duplicates()
        add("Remove duplicate rows", f"{b - len(out)} exact duplicate rows removed")
    drop = [c for c in cfg.drop_cols if c in out.columns]
    if drop:
        out = out.drop(columns=drop)
        add("Drop columns (manual)", ", ".join(drop))
    if cfg.col_missing_thresh < 100:
        pct = out.isna().mean() * 100
        hi = pct[pct > cfg.col_missing_thresh].index.tolist()
        if hi:
            out = out.drop(columns=hi)
        add("Drop sparse columns", f"{len(hi)} column(s) with > {cfg.col_missing_thresh:.0f}% missing" + (f": {', '.join(hi)}" if hi else ""))
    if cfg.row_missing_max is not None:
        nm = out.isna().sum(axis=1)
        b = len(out)
        out = out[nm <= cfg.row_missing_max]
        add("Drop sparse rows", f"{b - len(out)} row(s) with > {cfg.row_missing_max} missing cells removed")

    num_cols = [c for c in out.columns if is_numeric(out[c])]
    cat_cols = [c for c in out.columns if c not in num_cols]
    if cfg.num_strategy != "none":
        miss = [c for c in num_cols if out[c].isna().any()]
        if miss:
            strat, note = cfg.num_strategy, ""
            if strat == "knn" and (len(out) > KNN_ROW_LIMIT or len(num_cols) < 2):
                strat, note = "median", f" (KNN limited to {KNN_ROW_LIMIT} rows in this demo -> used median)"
            counts = {c: int(out[c].isna().sum()) for c in miss}
            if strat == "knn":
                usable = [c for c in num_cols if out[c].notna().any()]
                mu, sd = out[usable].mean(), out[usable].std().replace(0, 1)
                z = (out[usable] - mu) / sd
                out[usable] = KNNImputer(n_neighbors=5).fit_transform(z) * sd.values + mu.values
            else:
                for c in miss:
                    fill = {"mean": out[c].mean(), "median": out[c].median(), "constant": cfg.constant_value}[strat]
                    out[c] = out[c].fillna(fill)
            add(f"Impute numeric ({strat})", "; ".join(f"{c}: {n}" for c, n in counts.items()) + note)
    if cfg.cat_strategy != "none":
        miss = [c for c in cat_cols if out[c].isna().any()]
        if miss:
            counts = {c: int(out[c].isna().sum()) for c in miss}
            for c in miss:
                mode = out[c].mode()
                out[c] = out[c].fillna(mode.iloc[0] if (cfg.cat_strategy == "mode" and len(mode)) else "Unknown")
            add(f"Impute categorical ({cfg.cat_strategy})", "; ".join(f"{c}: {n}" for c, n in counts.items()))
    return out.reset_index(drop=True), log


# ============================================================ UNIT 2 - outliers
def outlier_bounds(s: pd.Series, method: str = "iqr", thr: float = 1.5) -> tuple[float, float]:
    s = s.dropna()
    if method == "iqr":
        q1, q3 = s.quantile([0.25, 0.75])
        i = q3 - q1
        return float(q1 - thr * i), float(q3 + thr * i)
    mu, sd = s.mean(), s.std(ddof=0)
    return float(mu - thr * sd), float(mu + thr * sd)


def outlier_summary(df: pd.DataFrame, cols: list[str], method: str, thr: float) -> pd.DataFrame:
    rows = []
    for c in cols:
        lo, hi = outlier_bounds(df[c], method, thr)
        n = int(((df[c] < lo) | (df[c] > hi)).sum())
        rows.append({"column": c, "lower bound": lo, "upper bound": hi, "outliers": n, "% of rows": round(n / max(len(df), 1) * 100, 2)})
    return pd.DataFrame(rows)


def treat_outliers(df: pd.DataFrame, cols: list[str], method: str, thr: float, treatment: str) -> tuple[pd.DataFrame, list[str]]:
    out, log = df.copy(), []
    if treatment == "none" or not cols:
        return out, log
    if treatment == "remove rows":
        mask = pd.Series(False, index=out.index)
        for c in cols:
            lo, hi = outlier_bounds(out[c], method, thr)
            mask |= (out[c] < lo) | (out[c] > hi)
        log.append(f"removed {int(mask.sum())} rows containing an outlier in {', '.join(cols)}")
        return out[~mask].reset_index(drop=True), log
    for c in cols:
        lo, hi = outlier_bounds(out[c], method, thr)
        m = (out[c] < lo) | (out[c] > hi)
        if treatment.startswith("cap"):
            out[c] = out[c].clip(lo, hi)
        else:
            out.loc[m, c] = out[c].median()
        log.append(f"{c}: {int(m.sum())} outliers {'capped to bounds' if treatment.startswith('cap') else 'replaced by median'}")
    return out, log


# ============================================================ UNIT 3 - descriptive
def describe_extended(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    rows = []
    for c in cols:
        s = df[c].dropna()
        mode = s.mode()
        rows.append({"column": c, "count": len(s), "mean": s.mean(), "median": s.median(),
                     "mode": mode.iloc[0] if len(mode) else np.nan, "std": s.std(), "variance": s.var(),
                     "min": s.min(), "Q1": s.quantile(.25), "Q3": s.quantile(.75), "max": s.max(),
                     "IQR": s.quantile(.75) - s.quantile(.25), "range": s.max() - s.min(), "skew": s.skew(),
                     "kurtosis": s.kurt(), "CV %": s.std() / s.mean() * 100 if s.mean() else np.nan})
    return pd.DataFrame(rows).set_index("column")


# ============================================================ UNIT 4 - diagnostic / inferential
def t_test(df, col, group_col, g1, g2) -> dict:
    a = df.loc[df[group_col].astype(str) == str(g1), col].dropna()
    b = df.loc[df[group_col].astype(str) == str(g2), col].dropna()
    t, p = stats.ttest_ind(a, b, equal_var=False)
    sp = np.sqrt(((len(a) - 1) * a.var() + (len(b) - 1) * b.var()) / max(len(a) + len(b) - 2, 1))
    return {"n1": len(a), "n2": len(b), "mean1": a.mean(), "mean2": b.mean(), "t": float(t), "p": float(p),
            "cohens_d": float((a.mean() - b.mean()) / sp) if sp > 0 else np.nan, "a": a, "b": b}


def anova(df, col, group_col) -> dict:
    groups = {str(k): g.dropna() for k, g in df.groupby(group_col, observed=True)[col] if g.notna().sum() > 1}
    F, p = stats.f_oneway(*[g.to_numpy() for g in groups.values()])
    allv = pd.concat(groups.values())
    ssb = sum(len(g) * (g.mean() - allv.mean()) ** 2 for g in groups.values())
    sst = ((allv - allv.mean()) ** 2).sum()
    return {"F": float(F), "p": float(p), "eta2": float(ssb / sst) if sst else np.nan, "groups": groups}


def chi_square(df, a, b) -> dict:
    ct = pd.crosstab(df[a], df[b])
    chi2, p, dof, exp = stats.chi2_contingency(ct)
    n = ct.values.sum()
    v = float(np.sqrt(chi2 / (n * (min(ct.shape) - 1)))) if min(ct.shape) > 1 else np.nan
    return {"observed": ct, "expected": pd.DataFrame(exp, index=ct.index, columns=ct.columns), "chi2": float(chi2),
            "p": float(p), "dof": int(dof), "cramers_v": v, "low_expected": int((exp < 5).sum())}


def bin_if_continuous(s: pd.Series, q: int = 4) -> pd.Series:
    if is_numeric(s) and s.nunique() > 20:
        return pd.qcut(s, q, duplicates="drop").astype(str)
    return s.astype(str)


def _kind(s: pd.Series) -> str | None:
    if is_numeric(s) and s.nunique() > 10:
        return "num"
    return "cat" if s.nunique() <= 20 else None


def driver_ranking(df: pd.DataFrame, target: str) -> pd.DataFrame:
    """Root-cause screening: association strength (0-1) of every column with the outcome."""
    tk, rows = _kind(df[target]), []
    for c in df.columns:
        if c == target:
            continue
        ck = _kind(df[c])
        d = df[[c, target]].dropna()
        if ck is None or tk is None or len(d) < 20 or d[c].nunique() < 2 or d[target].nunique() < 2:
            continue
        try:
            if tk == "num" and ck == "num":
                r, p = stats.pearsonr(d[c], d[target]); strength, measure = abs(r), "|Pearson r|"
            elif tk == "num":      # numeric outcome, categorical driver
                res = anova(d, target, c); strength, p, measure = np.sqrt(res["eta2"]), res["p"], "eta (ANOVA)"
            elif ck == "num":      # categorical outcome, numeric driver
                res = anova(d, c, target); strength, p, measure = np.sqrt(res["eta2"]), res["p"], "eta (ANOVA)"
            else:
                res = chi_square(d, c, target); strength, p, measure = res["cramers_v"], res["p"], "Cramer's V"
            rows.append({"feature": c, "measure": measure, "strength": float(strength), "p_value": float(p)})
        except Exception:
            continue
    return pd.DataFrame(rows, columns=["feature", "measure", "strength", "p_value"]).sort_values("strength", ascending=False).reset_index(drop=True)


# ============================================================ UNIT 5 - predictive
def detect_task(y: pd.Series) -> str:
    return "regression" if is_numeric(y) and y.nunique() > 10 else "classification"


def prepare_xy(df, target, features):
    d = df[list(features) + [target]].dropna()
    return pd.get_dummies(d[list(features)], drop_first=True).astype(float), d[target]


def leakage_suspects(df, target, features, thr: float = 0.95) -> list[str]:
    """Features that (almost) determine the label on their own - typically the label in disguise.
    Binary label: single-feature ROC-AUC >= 0.98 (catches threshold-defined labels). Numeric label: |r| >= thr.
    Categorical features: Cramer's V >= thr."""
    y, out = df[target], []
    kind = detect_task(y)
    classes = sorted(y.dropna().astype(str).unique())
    for f in features:
        d = df[[f, target]].dropna()
        if len(d) < 30 or d[f].nunique() < 2:
            continue
        try:
            if is_numeric(d[f]):
                if kind == "regression":
                    hit = abs(d[f].corr(d[target])) >= thr
                elif len(classes) == 2:
                    auc = roc_auc_score((d[target].astype(str) == classes[1]).astype(int), d[f])
                    hit = max(auc, 1 - auc) >= 0.98
                else:
                    hit = False
            else:
                hit = kind == "classification" and chi_square(d, f, target)["cramers_v"] >= thr
        except Exception:
            hit = False
        if hit:
            out.append(f)
    return out


def fit_regression(df, target, features, test_size=0.25, seed=42) -> dict:
    X, y = prepare_xy(df, target, features)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=test_size, random_state=seed)
    pipe = make_pipeline(StandardScaler(), LinearRegression()).fit(Xtr, ytr)
    pred = pipe.predict(Xte)
    lr, sc = pipe[-1], pipe[0]
    coef = pd.DataFrame({"feature": X.columns, "coef (per 1 SD)": lr.coef_, "coef (original units)": lr.coef_ / sc.scale_})
    coef = coef.reindex(coef["coef (per 1 SD)"].abs().sort_values(ascending=False).index).reset_index(drop=True)
    return {"model": pipe, "columns": list(X.columns), "X": X,
            "metrics": {"R2 (test)": r2_score(yte, pred), "R2 (train)": pipe.score(Xtr, ytr),
                        "RMSE": float(np.sqrt(mean_squared_error(yte, pred))), "MAE": mean_absolute_error(yte, pred)},
            "coef": coef, "y_test": yte, "pred": pred, "X_test": Xte, "intercept": float(lr.intercept_)}


def fit_classification(df, target, features, models, test_size=0.25, seed=42, balanced=True) -> dict:
    X, y = prepare_xy(df, target, features)
    le = LabelEncoder().fit(y.astype(str))
    yy = pd.Series(le.transform(y.astype(str)), index=y.index)
    strat = yy if yy.value_counts().min() >= 2 else None
    Xtr, Xte, ytr, yte = train_test_split(X, yy, test_size=test_size, random_state=seed, stratify=strat)
    cw = "balanced" if balanced else None
    zoo = {"Logistic Regression": LogisticRegression(max_iter=2000, class_weight=cw),
           "SVM (RBF kernel)": SVC(kernel="rbf", class_weight=cw), "SVM (linear kernel)": SVC(kernel="linear", class_weight=cw)}
    binary, res = len(le.classes_) == 2, {}
    for name in models:
        Xf, yf = (Xtr, ytr) if (not name.startswith("SVM") or len(Xtr) <= 4000) else (Xtr.iloc[:4000], ytr.iloc[:4000])
        pipe = make_pipeline(StandardScaler(), zoo[name]).fit(Xf, yf)
        pred = pipe.predict(Xte)
        avg = "binary" if binary else "macro"
        m = {"Accuracy": accuracy_score(yte, pred), "Precision": precision_score(yte, pred, average=avg, zero_division=0),
             "Recall": recall_score(yte, pred, average=avg, zero_division=0), "F1": f1_score(yte, pred, average=avg, zero_division=0),
             "ROC-AUC": np.nan}
        roc = None
        if binary:
            score = pipe.decision_function(Xte)
            m["ROC-AUC"] = roc_auc_score(yte, score)
            fpr, tpr, _ = roc_curve(yte, score)
            roc = (fpr, tpr)
        elif name == "Logistic Regression":
            m["ROC-AUC"] = roc_auc_score(yte, pipe.predict_proba(Xte), multi_class="ovr")
        res[name] = {"model": pipe, "metrics": m, "cm": confusion_matrix(yte, pred), "roc": roc}
    coefs = None
    if "Logistic Regression" in res and binary:
        lr = res["Logistic Regression"]["model"][-1]
        coefs = pd.DataFrame({"feature": X.columns, "coef (per 1 SD)": lr.coef_[0]})
        coefs = coefs.reindex(coefs["coef (per 1 SD)"].abs().sort_values(ascending=False).index).reset_index(drop=True)
    return {"results": res, "classes": list(le.classes_), "columns": list(X.columns), "X": X, "binary": binary,
            "baseline_acc": float(yte.value_counts(normalize=True).max()), "coefs": coefs}


# ============================================================ monitoring bridge (Project 14 drift idea)
def psi_table(ref: pd.DataFrame, new: pd.DataFrame, cols: list[str], bins: int = 10, warn=0.10, alert=0.25) -> pd.DataFrame:
    rows = []
    for c in cols:
        r, n = ref[c].dropna().to_numpy(), new[c].dropna().to_numpy()
        if len(r) < 20 or len(n) < 20:
            continue
        edges = np.unique(np.quantile(r, np.linspace(0, 1, bins + 1)))
        if len(edges) < 3:
            continue
        edges[0], edges[-1] = -np.inf, np.inf
        rf = np.clip(np.histogram(r, edges)[0] / len(r), 1e-4, None)
        nf = np.clip(np.histogram(n, edges)[0] / len(n), 1e-4, None)
        v = float(np.sum((nf - rf) * np.log(nf / rf)))
        rows.append({"feature": c, "PSI": round(v, 4), "status": "ALERT" if v >= alert else "warn" if v >= warn else "ok"})
    return pd.DataFrame(rows, columns=["feature", "PSI", "status"]).sort_values("PSI", ascending=False).reset_index(drop=True)
