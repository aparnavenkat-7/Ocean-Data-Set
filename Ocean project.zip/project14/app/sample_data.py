"""Built-in demo dataset: the Project 14 hydroacoustic ocean-plastic simulator, deliberately left messy."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from opm.config import Config  # noqa: E402
from opm.synthetic import generate_dataset  # noqa: E402


@st.cache_data(show_spinner="Generating sample ocean-plastic data ...")
def load_sample(n_rows: int = 3000, seed: int = 7) -> pd.DataFrame:
    cfg = Config(n_days=30)
    df = generate_dataset(cfg, seed=seed).drop(columns=["time"])
    rng = np.random.default_rng(seed)
    df = df.sample(n_rows, random_state=seed).sort_values(["day", "cell_id"]).reset_index(drop=True)
    df["quadrant"] = np.where(df["y"] >= 0, "N", "S") + np.where(df["x"] >= 0, "E", "W")
    df["sensor_status"] = rng.choice(["ok", "degraded"], size=len(df), p=[0.88, 0.12])
    df["sensor_status"] = df["sensor_status"].astype(object)
    df.loc[rng.random(len(df)) < 0.03, "sensor_status"] = np.nan
    df["sensor_status"] = df["sensor_status"].mask(rng.random(len(df)) < 0.02, "N/A")
    # corrupted numeric column: strings inside a numeric field
    col = df["band_45_50"].round(2).astype(object)
    idx = rng.choice(len(df), size=int(0.02 * len(df)), replace=False)
    col.iloc[idx] = rng.choice(["error", "--", "###", "N/A", "?"], size=len(idx))
    df["band_45_50"] = col
    note = pd.Series([None] * len(df), dtype=object)                                  # almost-empty column (to be dropped)
    note[rng.random(len(df)) >= 0.92] = "check"
    df["buoy_note"] = note
    return df
