"""Step 3 - Exploratory data analysis (Unit 2: uni/bi/multivariate analysis, outlier detection & treatment)."""
import numpy as np
import pandas as pd
import streamlit as st
from scipy import stats

import core
import ui


def _numeric(df):
    return [c for c in df.columns if core.is_numeric(df[c]) and df[c].nunique() > 2]


def _cats(df, maxn=12):
    return [c for c in df.columns if (not core.is_numeric(df[c]) or df[c].nunique() <= 10) and 2 <= df[c].nunique() <= maxn]


def _skew_text(sk):
    return ("roughly symmetric" if abs(sk) < 0.5 else "moderately skewed" if abs(sk) < 1 else "strongly skewed") + \
        (" (long right tail)" if sk > 0.5 else " (long left tail)" if sk < -0.5 else "")


def _strength(r):
    a = abs(r)
    return "negligible" if a < .1 else "weak" if a < .3 else "moderate" if a < .5 else "strong" if a < .8 else "very strong"


def render():
    ss = st.session_state
    ui.page_header(2, "Purpose & techniques of EDA · univariate · bivariate · multivariate · outliers")
    df = ss.data.get(1)
    if df is None:
        st.stop()
    nums, cats = _numeric(df), _cats(df)
    if not nums:
        st.error("No numeric columns to explore. Go back and check the cleaning step.")
        ui.proceed_bar(2, False, "Need numeric columns.")
        return
    ui.concept("What EDA is for", """
EDA looks at the data *before* modelling to understand shape, relationships and anomalies.
**Univariate**: one variable (histogram, box plot, violin, frequency table). **Bivariate**: two variables (scatter, correlation,
covariance). **Multivariate**: many at once (correlation heatmap, pair plot). **Outliers**: values far from the bulk -
detect with the IQR rule or Z-score, then keep, cap, replace or remove.
""")
    tU, tB, tM, tO = st.tabs(["Univariate", "Bivariate", "Multivariate", "Outliers: detect & treat"])

    with tU:
        kind = st.radio("Variable type", ["Numeric", "Categorical"], horizontal=True, key="w_ukind")
        if kind == "Numeric":
            c = st.selectbox("Column", nums, key="w_ucol")
            s = df[c].dropna()
            bins = st.slider("Histogram bins", 5, 100, 30, key="w_ubins")
            f, axs = ui.fig(11, 3.4, ncols=3)
            axs[0].hist(s, bins=bins, density=True, alpha=.65)
            if s.nunique() > 3:
                xs = np.linspace(s.min(), s.max(), 200); axs[0].plot(xs, stats.gaussian_kde(s)(xs), lw=2)
            axs[0].set_title("Histogram + density")
            ui.boxplot(axs[1], s, patch_artist=True); axs[1].set_title("Box plot")
            axs[2].violinplot(s, showmeans=True, showmedians=True); axs[2].set_title("Violin plot")
            ui.show_fig(f)
            lo, hi = core.outlier_bounds(s)
            m = st.columns(5)
            m[0].metric("Mean", f"{s.mean():.3g}"); m[1].metric("Median", f"{s.median():.3g}")
            m[2].metric("Std dev", f"{s.std():.3g}"); m[3].metric("Skewness", f"{s.skew():.2f}")
            m[4].metric("IQR outliers", int(((s < lo) | (s > hi)).sum()))
            st.info(f"**Reading it:** `{c}` is {_skew_text(s.skew())}; mean {'>' if s.mean() > s.median() else '<'} median "
                    f"{'confirms the right tail' if s.mean() > s.median() else 'confirms the left tail'} - so the median is the safer "
                    f"summary when outliers are present.")
        elif cats:
            c = st.selectbox("Column", cats, key="w_ucatcol")
            vc = df[c].astype(str).value_counts()
            ft = pd.DataFrame({"count": vc, "relative freq %": (vc / vc.sum() * 100).round(2)})
            a, b = st.columns([1, 1.4])
            with a: ui.show_df(ft)
            with b:
                f, ax = ui.fig(5.5, 3.2); ax.bar(ft.index, ft["count"]); ax.set_title(f"Frequency distribution: {c}")
                ui.show_fig(f)
        else:
            st.info("No categorical columns available.")

    with tB:
        if len(nums) < 2:
            st.info("Need at least two numeric columns.")
        else:
            a, b, h = st.columns(3)
            x = a.selectbox("X axis", nums, key="w_bx")
            y = b.selectbox("Y axis", nums, index=min(1, len(nums) - 1), key="w_by")
            hue = h.selectbox("Colour by (optional)", ["(none)"] + cats, key="w_bhue")
            d = df[[x, y] + ([] if hue == "(none)" else [hue])].dropna()
            sm = d.sample(min(len(d), 3000), random_state=0)
            f, ax = ui.fig(7, 4)
            if hue == "(none)":
                ax.scatter(sm[x], sm[y], s=8, alpha=.45)
            else:
                for i, (g, gd) in enumerate(sm.groupby(hue)):
                    ax.scatter(gd[x], gd[y], s=8, alpha=.5, label=str(g), color=ui.PALETTE[i % 8])
                ax.legend(title=hue, markerscale=2)
            if x != y:
                k, i0 = np.polyfit(d[x], d[y], 1); xs = np.array([d[x].min(), d[x].max()])
                ax.plot(xs, k * xs + i0, "k--", lw=1.5, label="trend")
            ax.set_xlabel(x); ax.set_ylabel(y)
            ui.show_fig(f)
            if x != y:
                pr, pp = stats.pearsonr(d[x], d[y]); sr, _ = stats.spearmanr(d[x], d[y]); cov = np.cov(d[x], d[y])[0, 1]
                m = st.columns(3)
                m[0].metric("Pearson r", f"{pr:.3f}"); m[1].metric("Spearman ρ", f"{sr:.3f}"); m[2].metric("Covariance", f"{cov:.4g}")
                st.info(f"**Reading it:** a {_strength(pr)} {'positive' if pr > 0 else 'negative'} linear relationship (p = {pp:.2g}). "
                        f"Covariance has the same sign but depends on units; correlation rescales it to −1…+1. "
                        f"{'Spearman differs a lot from Pearson → relationship is non-linear or outlier-driven.' if abs(sr - pr) > .15 else ''}")

    with tM:
        method = st.radio("Correlation method", ["pearson", "spearman"], horizontal=True, key="w_cmeth")
        sel = st.multiselect("Columns for the heatmap", nums, default=core.default_numeric(df, nums, 12), key="w_hcols")
        if len(sel) >= 2:
            cm = df[sel].corr(method=method)
            f, ax = ui.fig(0.62 * len(sel) + 3, 0.55 * len(sel) + 2.2)
            im = ax.imshow(cm, cmap="coolwarm", vmin=-1, vmax=1); ax.grid(False)
            ax.set_xticks(range(len(sel))); ax.set_xticklabels(sel, rotation=90); ax.set_yticks(range(len(sel))); ax.set_yticklabels(sel)
            if len(sel) <= 12:
                for i in range(len(sel)):
                    for j in range(len(sel)):
                        ax.text(j, i, f"{cm.iloc[i, j]:.2f}", ha="center", va="center", fontsize=7)
            f.colorbar(im, shrink=.8); ui.show_fig(f)
            pairs = cm.where(np.triu(np.ones(cm.shape), 1).astype(bool)).stack().abs().sort_values(ascending=False)
            if len(pairs):
                st.info(f"**Strongest pair:** `{pairs.index[0][0]}` ↔ `{pairs.index[0][1]}` (|r| = {pairs.iloc[0]:.2f}). "
                        f"Highly correlated predictors (|r| > 0.9) carry duplicate information (multicollinearity).")
        st.markdown("**Pair plot**")
        ps = st.multiselect("Choose 2-5 columns", nums, default=core.default_numeric(df, nums, 4), max_selections=5, key="w_pcols")
        ph = st.selectbox("Colour by", ["(none)"] + cats, key="w_phue")
        if len(ps) >= 2:
            d = df[ps + ([] if ph == "(none)" else [ph])].dropna()
            d = d.sample(min(len(d), 700), random_state=0)
            n = len(ps)
            f, axs = ui.fig(2.2 * n, 2.0 * n, nrows=n, ncols=n)
            groups = [(None, d)] if ph == "(none)" else list(d.groupby(ph))
            for i in range(n):
                for j in range(n):
                    ax = axs[i, j]; ax.grid(False)
                    for gi, (g, gd) in enumerate(groups):
                        col = ui.PALETTE[gi % 8]
                        if i == j:
                            ax.hist(gd[ps[i]], bins=20, alpha=.5, color=col)
                        else:
                            ax.scatter(gd[ps[j]], gd[ps[i]], s=3, alpha=.4, color=col)
                    if i == n - 1: ax.set_xlabel(ps[j], fontsize=7)
                    if j == 0: ax.set_ylabel(ps[i], fontsize=7)
                    ax.tick_params(labelsize=6)
            ui.show_fig(f)

    with tO:
        st.markdown("Outliers can be genuine events or sensor faults. Detect them, then choose how to treat them.")
        a, b, c3, d4 = st.columns(4)
        cols = a.multiselect("Columns to check", nums, default=core.default_numeric(df, nums, 6), key="w_ocols")
        method = b.radio("Detection", ["iqr", "zscore"], format_func=lambda m: "IQR rule" if m == "iqr" else "Z-score", key="w_ometh")
        thr = c3.slider("IQR multiplier" if method == "iqr" else "Z threshold", 1.0, 5.0, 1.5 if method == "iqr" else 3.0, 0.1, key="w_othr")
        treat = d4.selectbox("Treatment", ["none", "cap (winsorize)", "replace with median", "remove rows"], key="w_otreat")
        if cols:
            summ = core.outlier_summary(df, cols, method, thr)
            ui.show_df(summ.round(3))
            treated, tlog = core.treat_outliers(df, cols, method, thr, treat)
            pick = st.selectbox("Compare before / after for", cols, key="w_opick")
            f, axs = ui.fig(9, 3.2, ncols=2, sharey=True)
            ui.boxplot(axs[0], df[pick].dropna(), horizontal=True, patch_artist=True); axs[0].set_title(f"Before ({len(df):,} rows)")
            ui.boxplot(axs[1], treated[pick].dropna(), horizontal=True, patch_artist=True); axs[1].set_title(f"After - {treat} ({len(treated):,} rows)")
            ui.show_fig(f)
            if tlog:
                st.success(" · ".join(tlog))
        else:
            treated, tlog = df, []
        ss.pending[2] = treated
        ui.record(2, "outliers", f"{method.upper()} detection (threshold {thr}); treatment = {treat}. " + " ".join(tlog))
        ui.record(2, "shape", f"{len(treated):,} rows × {treated.shape[1]} columns passed to analytics.")
    ui.proceed_bar(2)
