"""Step 1 - Upload & Introduction (Unit 1: types of data, challenges of real-world data)."""
import pandas as pd
import streamlit as st

import core
import ui
from sample_data import load_sample

MAX_ROWS = 50_000


def _read(up) -> pd.DataFrame:
    if up.name.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(up)
    return pd.read_csv(up, low_memory=False, encoding_errors="replace")


def render():
    ss = st.session_state
    st.title("Data-Driven Analytics of Ocean Plastic Accumulation")
    st.caption("Hydroacoustic signals, current patterns and convergence-zone prediction · SDG 14 (Life Below Water)")
    ui.page_header(0, "Introduction to data analytics · types of data · challenges of real-world data")
    ui.concept("Types of data & why real data is messy", """
**Quantitative** data are numbers you can do arithmetic on - *continuous* (current speed, dB level) or *discrete* (counts).
**Qualitative** (categorical) data are labels - *nominal* (quadrant N/S/E/W) or *binary* (zone / not zone).

Real-world data is rarely analysis-ready: **missing values**, **corrupted entries** (text inside numeric fields, sensor
error codes), **duplicates**, **outliers** and inconsistent types. This page profiles those problems *before* touching anything.
""", expanded=True)
    st.markdown("**The pipeline you are about to walk through:** Upload → Clean → Explore (EDA) → Describe → Diagnose → Predict → Report")

    src = st.radio("Choose a data source", ["Use the sample: Project 14 ocean-plastic hydroacoustics (deliberately messy)",
                                            "Upload my own CSV / Excel file"], key="w_src")
    df, name = None, ""
    if src.startswith("Use"):
        df, name = load_sample(), "ocean_plastic_sample"
        st.caption("Simulated hydrophone hiss (20-50 kHz) + surface currents on a 20x20 grid, with injected faults: "
                   "dropouts, spikes, duplicates, corrupted strings, sparse columns.")
    else:
        up = st.file_uploader("Drop a .csv / .xlsx file", type=["csv", "xlsx", "xls"], key="w_upload")
        if up is not None:
            try:
                df, name = _read(up), up.name
            except Exception as e:
                st.error(f"Could not read that file: {e}")
    if df is None or df.empty:
        st.info("Pick the sample or upload a file to begin.")
        ui.proceed_bar(0, can_proceed=False, hint="Load a dataset first.")
        return
    if len(df) > MAX_ROWS:
        df = df.sample(MAX_ROWS, random_state=0).sort_index().reset_index(drop=True)
        st.warning(f"Large file: using a random sample of {MAX_ROWS:,} rows to keep the demo responsive.")
    df.columns = [str(c).strip() for c in df.columns]
    ss.pending[0], ss.dataset_name = df, name

    q = core.quality_report(df)
    st.subheader("1 · First look")
    c = st.columns(5)
    c[0].metric("Rows", f"{q['rows']:,}"); c[1].metric("Columns", q["cols"])
    c[2].metric("Missing cells", f"{q['missing_cells']:,}", f"{q['missing_pct']:.1f}% of all cells", delta_color="off")
    c[3].metric("Duplicate rows", q["duplicate_rows"]); c[4].metric("Corrupted columns", len(q["corrupted"]))
    ui.show_df(df.head(12))

    st.subheader("2 · Data types: quantitative vs qualitative")
    types = core.classify_columns(df)
    ui.show_df(types)
    nq = types["data type"].str.startswith("Quantitative").sum()
    st.caption(f"{nq} quantitative and {len(types) - nq} qualitative/other columns detected from the values (not just the pandas dtype).")

    st.subheader("3 · Challenges of real-world data")
    l, r = st.columns(2)
    with l:
        miss = q["missing_by_col"][q["missing_by_col"] > 0].sort_values()
        f, ax = ui.fig(5.5, max(2.2, 0.32 * len(miss) + 0.8))
        if len(miss):
            ax.barh(miss.index, miss.values); ax.set_xlabel("% missing (incl. placeholder tokens)")
            ax.set_title("Missing data by column")
        else:
            ax.text(0.5, 0.5, "No missing data 🎉", ha="center"); ax.axis("off")
        ui.show_fig(f)
    with r:
        st.markdown("**Corrupted numeric columns** (text hiding inside numbers)")
        if len(q["corrupted"]):
            ui.show_df(q["corrupted"])
        else:
            st.success("None detected.")
        if q["constant_cols"]:
            st.warning(f"Constant / empty columns (no information): {', '.join(q['constant_cols'])}")
        st.markdown(f"**Duplicate rows:** {q['duplicate_rows']}")
    ui.record(0, "dataset", f"`{name}`: {q['rows']:,} rows × {q['cols']} columns; {q['missing_pct']:.1f}% missing cells, "
                            f"{q['duplicate_rows']} duplicate rows, {len(q['corrupted'])} corrupted column(s).")
    ui.proceed_bar(0)
