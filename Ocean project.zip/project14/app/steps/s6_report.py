"""Step 7 - Report & monitoring (wrap-up + the Project 14 MLOps drift idea)."""
from datetime import datetime

import numpy as np
import pandas as pd
import streamlit as st

import core
import ui

LABELS = {0: "1 · Upload & Introduction", 1: "2 · Data Cleaning", 2: "3 · Exploratory Data Analysis", 3: "4 · Descriptive Analytics",
          4: "5 · Diagnostic Analytics", 5: "6 · Predictive Analytics"}


def _markdown_report() -> str:
    ss = st.session_state
    lines = [f"# Data Analytics Report - {ss.dataset_name}", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    for i, title in LABELS.items():
        lines.append(f"## {title}")
        items = ss.findings.get(i, {})
        lines += [f"- {v}" for v in items.values()] or ["- (step not completed)"]
        lines.append("")
    return "\n".join(lines)


def render():
    ss = st.session_state
    ui.page_header(6, "Findings summary · deployment & monitoring (concept drift)")
    df = ss.data.get(2)
    if df is None:
        st.stop()
    t1, t2 = st.tabs(["📄 Pipeline report", "📡 Monitoring (MLOps bonus)"])
    with t1:
        st.markdown(f"#### Report for `{ss.dataset_name}`")
        for i, title in LABELS.items():
            with st.expander(title, expanded=i in (1, 4, 5)):
                items = ss.findings.get(i, {})
                for v in items.values():
                    st.markdown(f"- {v}")
                if not items:
                    st.caption("Not completed yet.")
        a, b = st.columns(2)
        a.download_button("⬇ Download report (.md)", _markdown_report().encode(), "analytics_report.md", "text/markdown")
        b.download_button("⬇ Download analysis-ready data (.csv)", df.to_csv(index=False).encode(), "analysis_ready.csv", "text/csv")
    with t2:
        ui.concept("Why models need monitoring", """
A model is only as good as the data it sees. When incoming data **drifts** (a sensor is replaced, seasons change, a gyre moves), accuracy silently decays.
The **Population Stability Index (PSI)** compares the live distribution to the reference: **< 0.10 stable · 0.10-0.25 warning · > 0.25 alert → retrain**.
This is the same check Project 14's MLOps pipeline (`python main.py monitor`) runs automatically against its champion model.
""", expanded=True)
        nums = [c for c in df.columns if core.is_numeric(df[c]) and df[c].nunique() > 10]
        mode = st.radio("New batch", ["Simulate drift on the current data", "Upload a new batch (CSV)"], horizontal=True, key="w_mon")
        new = None
        if mode.startswith("Sim"):
            cols = st.multiselect("Columns to disturb", nums, default=nums[:2], key="w_mcols")
            shift = st.slider("Shift mean by (standard deviations)", -3.0, 3.0, 1.0, 0.25, key="w_mshift")
            new = df.sample(frac=1, random_state=3).copy()
            for c in cols:
                new[c] = new[c] + shift * df[c].std()
        else:
            up = st.file_uploader("New batch (same columns)", type=["csv"], key="w_mupload")
            if up is not None:
                new = pd.read_csv(up)
        if new is not None:
            common = [c for c in nums if c in new.columns and core.is_numeric(new[c])]
            res = core.psi_table(df, new, common)
            if len(res):
                share = (res["status"] == "ALERT").mean()
                ui.verdict(share < 0.2, f"{(res['status'] == 'ALERT').sum()} of {len(res)} features in ALERT → "
                                        + ("stable, keep serving the current model." if share < 0.2 else "**drift detected - retrain the model** (Project 14 would trigger the retrain flow)."))
                f, ax = ui.fig(7, 0.3 * len(res) + 1.4)
                col = res["status"].map({"ok": "#2f9e44", "warn": "#f08c00", "ALERT": "#c92a2a"})
                ax.barh(res["feature"][::-1], res["PSI"][::-1], color=col[::-1]); ax.axvline(0.10, ls="--", c="gray"); ax.axvline(0.25, ls="--", c="red"); ax.set_xlabel("PSI")
                ui.show_fig(f); ui.show_df(res)
            else:
                st.info("No comparable numeric columns found.")
    ui.proceed_bar(6)
