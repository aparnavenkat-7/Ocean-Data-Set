"""Step 6 - Predictive analytics (Unit 5: features & labels, simple/multiple regression, logistic regression, SVM)."""
import numpy as np
import pandas as pd
import streamlit as st

import core
import ui


def render():
    ss = st.session_state
    ui.page_header(5, "Features and labels · simple & multiple regression · logistic regression · SVM")
    df = ss.data.get(2)
    if df is None:
        st.stop()
    ui.concept("Features, labels and the models", """
**Features (X)** are the inputs; the **label (y)** is what we predict. A *numeric* label → **regression**; a *category* label → **classification**.
* **Simple regression**: y = b₀ + b₁x (one feature). **Multiple regression**: y = b₀ + b₁x₁ + b₂x₂ + … (many features).
* **Logistic regression**: models the probability of a class with an S-shaped curve; the decision boundary is linear.
* **SVM**: finds the boundary with the widest margin between classes; the **RBF kernel** can bend the boundary.
Always judge a model on **unseen test data**, and compare against a trivial **baseline**.
""")
    cols = list(df.columns)
    default_t = cols.index("plastic_density") if "plastic_density" in cols else len(cols) - 1
    target = st.selectbox("1 · Choose the label (y) to predict", cols, index=default_t, key="w_ptarget")
    task = core.detect_task(df[target])
    st.info(f"Label `{target}` has {df[target].nunique()} distinct values → **{task}** task.")

    id_like = [c for c in cols if c != target and (df[c].nunique() == len(df) or c.lower() in ("id", "cell_id", "index"))]
    cand = [c for c in cols if c != target and c not in id_like and (core.is_numeric(df[c]) or df[c].nunique() <= 15)]
    suspects = core.leakage_suspects(df, target, cand) if cand else []
    default_feats = [c for c in cand if c not in suspects]
    feats = st.multiselect("2 · Choose features (X)", cand, default=default_feats, key="w_pfeats")
    if suspects:
        st.warning(f"⚠ Possible **data leakage**: {', '.join(f'`{c}`' for c in suspects)} is almost perfectly associated with `{target}` "
                   f"(it may be the outcome in another form). Excluded by default - a model using it looks perfect but is useless in practice.")
    if id_like:
        st.caption(f"Identifier-like columns excluded: {', '.join(id_like)}")
    if not feats:
        st.info("Select at least one feature.")
        ui.proceed_bar(5, False, "Select features.")
        return

    a, b, c = st.columns(3)
    test_size = a.slider("Test set share", 0.1, 0.4, 0.25, 0.05, key="w_ptest")
    seed = b.number_input("Random seed", 0, 9999, 42, key="w_pseed")
    if task == "regression":
        mode = c.radio("Model", ["Simple regression (1 feature)", "Multiple regression (all selected)"], key="w_preg")
        use = feats
        if mode.startswith("Simple"):
            numf = [f for f in feats if core.is_numeric(df[f])]
            if not numf:
                st.warning("Simple regression needs a numeric feature - select one above.")
                ui.proceed_bar(5, False, "Select a numeric feature.")
                return
            corr = df[numf].corrwith(df[target]).abs().sort_values(ascending=False)
            use = [st.selectbox("Feature for simple regression", numf, index=numf.index(corr.index[0]) if len(corr) else 0, key="w_psimple")]
        sig = ("reg", target, tuple(use), test_size, seed)
    else:
        models = c.multiselect("Models", ["Logistic Regression", "SVM (RBF kernel)", "SVM (linear kernel)"], default=["Logistic Regression", "SVM (RBF kernel)"], key="w_pmodels")
        bal = st.checkbox("Balance classes (class_weight='balanced') - recommended when one class is rare", True, key="w_pbal")
        use = feats
        sig = ("clf", target, tuple(use), test_size, seed, tuple(models), bal)

    st.markdown(f"**Features (X):** {', '.join(use)}  →  **Label (y):** `{target}`")
    if st.button("🚀 Train & evaluate", type="primary", key="btn_train"):
        with st.spinner("Training ..."):
            try:
                if task == "regression":
                    ss["pred"] = (sig, "reg", core.fit_regression(df, target, use, test_size, int(seed)))
                else:
                    if not models:
                        st.error("Choose at least one model."); st.stop()
                    ss["pred"] = (sig, "clf", core.fit_classification(df, target, use, models, test_size, int(seed), bal))
            except Exception as e:
                st.error(f"Training failed: {e}")
    stored = ss.get("pred")
    if not stored or stored[0] != sig:
        st.caption("Configure above, then press **Train & evaluate**.")
        ui.proceed_bar(5, can_proceed=False, hint="Train a model first.")
        return
    _, kind, res = stored
    st.divider()
    if kind == "reg":
        _show_regression(res, target, use)
    else:
        _show_classification(res, target)
    ui.proceed_bar(5)


def _show_regression(res, target, use):
    m = res["metrics"]
    c = st.columns(4)
    c[0].metric("R² (test)", f"{m['R2 (test)']:.3f}"); c[1].metric("R² (train)", f"{m['R2 (train)']:.3f}")
    c[2].metric("RMSE", f"{m['RMSE']:.4g}"); c[3].metric("MAE", f"{m['MAE']:.4g}")
    gap = m["R2 (train)"] - m["R2 (test)"]
    st.info(f"The model explains **{m['R2 (test)'] * 100:.1f}%** of the variance in `{target}` on unseen data. "
            + ("Train and test R² are close → no sign of overfitting." if gap < 0.1 else "Train ≫ test R² → overfitting; use fewer features."))
    l, r = st.columns(2)
    with l:
        f, ax = ui.fig(5, 3.8)
        if len(use) == 1:
            x = res["X_test"].iloc[:, 0]; ax.scatter(x, res["y_test"], s=8, alpha=.4, label="actual")
            o = np.argsort(x.to_numpy()); ax.plot(x.to_numpy()[o], res["pred"][o], "r-", lw=2, label="fitted line"); ax.set_xlabel(use[0]); ax.set_ylabel(target)
        else:
            ax.scatter(res["y_test"], res["pred"], s=8, alpha=.4); lim = [res["y_test"].min(), res["y_test"].max()]; ax.plot(lim, lim, "r--"); ax.set_xlabel("actual"); ax.set_ylabel("predicted")
        ax.set_title("Fit on the test set"); ax.legend() if len(use) == 1 else None
        ui.show_fig(f)
    with r:
        resid = res["y_test"].to_numpy() - res["pred"]
        f, ax = ui.fig(5, 3.8); ax.hist(resid, bins=40); ax.axvline(0, color="r"); ax.set_title("Residuals (should centre on 0)")
        ui.show_fig(f)
    st.markdown("**Coefficients** - `per 1 SD` lets you compare feature importance; `original units` is the slope in real units.")
    ui.show_df(res["coef"].round(5))
    ui.record(5, "model", f"Regression for `{target}` using {len(use)} feature(s): test R²={m['R2 (test)']:.3f}, RMSE={m['RMSE']:.4g}.")
    _predict_widget(res, "reg")


def _show_classification(res, target):
    rows = {n: v["metrics"] for n, v in res["results"].items()}
    tab = pd.DataFrame(rows).T
    tab.loc["Baseline: always predict majority", "Accuracy"] = res["baseline_acc"]
    st.markdown("**Model comparison (test set)**")
    ui.show_df(tab.round(4))
    best = max(res["results"], key=lambda n: res["results"][n]["metrics"]["F1"])
    st.info(f"Best F1: **{best}** ({res['results'][best]['metrics']['F1']:.3f}). Baseline accuracy is {res['baseline_acc']:.3f} - "
            "a model must beat that; with rare classes accuracy alone is misleading, so read precision / recall / F1.")
    names = list(res["results"])
    cols = st.columns(len(names))
    for col, n in zip(cols, names):
        with col:
            cm = res["results"][n]["cm"]
            f, ax = ui.fig(3.2, 3); ax.imshow(cm, cmap="Blues"); ax.grid(False)
            ax.set_xticks(range(len(res["classes"]))); ax.set_xticklabels(res["classes"]); ax.set_yticks(range(len(res["classes"]))); ax.set_yticklabels(res["classes"])
            for i in range(cm.shape[0]):
                for j in range(cm.shape[1]):
                    ax.text(j, i, cm[i, j], ha="center", va="center", color="black")
            ax.set_xlabel("predicted"); ax.set_ylabel("actual"); ax.set_title(n, fontsize=9)
            ui.show_fig(f)
    if res["binary"]:
        f, ax = ui.fig(5, 3.6)
        for n in names:
            fpr, tpr = res["results"][n]["roc"]; ax.plot(fpr, tpr, label=f"{n} (AUC {res['results'][n]['metrics']['ROC-AUC']:.3f})")
        ax.plot([0, 1], [0, 1], "k--"); ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate"); ax.legend(fontsize=7); ax.set_title("ROC curves")
        ui.show_fig(f)
    if res["coefs"] is not None:
        st.markdown("**Logistic regression coefficients** (per 1 SD; positive pushes toward the second class)")
        ui.show_df(res["coefs"].round(4))
    ui.record(5, "model", f"Classification of `{target}`: best model {best} with F1={res['results'][best]['metrics']['F1']:.3f}, "
                          f"ROC-AUC={res['results'][best]['metrics']['ROC-AUC']:.3f}; majority baseline accuracy {res['baseline_acc']:.3f}.")
    _predict_widget(res, "clf", best)


def _predict_widget(res, kind, best=None):
    with st.expander("🎛 Try the model: predict for a new observation"):
        X = res["X"]
        vals = {}
        cols = st.columns(3)
        for i, c in enumerate(X.columns):
            lo, hi, med = float(X[c].min()), float(X[c].max()), float(X[c].median())
            if lo == hi:
                vals[c] = lo
            elif set(X[c].unique()) <= {0.0, 1.0}:
                vals[c] = float(cols[i % 3].checkbox(c, bool(med), key=f"w_try_{c}"))
            else:
                vals[c] = cols[i % 3].slider(c, lo, hi, med, key=f"w_try_{c}")
        row = pd.DataFrame([vals])
        if kind == "reg":
            st.metric("Predicted value", f"{res['model'].predict(row)[0]:.4g}")
        else:
            m = res["results"][best]["model"]
            st.metric(f"Predicted class ({best})", str(res["classes"][int(m.predict(row)[0])]))
