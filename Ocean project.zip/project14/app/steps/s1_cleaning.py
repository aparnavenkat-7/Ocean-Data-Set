"""Step 2 - Data cleaning (Unit 1: missing data, corrupted data, cleaning techniques, imputation)."""
import pandas as pd
import streamlit as st

import core
import ui

NUM = {"Median": "median", "Mean": "mean", "KNN (k=5, uses similar rows)": "knn", "Constant value": "constant", "Leave as is": "none"}
CAT = {"Most frequent (mode)": "mode", "Fill with 'Unknown'": "unknown", "Leave as is": "none"}


@st.cache_data(show_spinner=False)
def _clean(df, cfg):
    return core.clean_dataframe(df, cfg)


def render():
    ss = st.session_state
    ui.page_header(1, "Techniques of data cleaning · handling missing & corrupted data · imputation")
    raw = ss.data.get(0)
    if raw is None:
        st.stop()
    ui.concept("Cleaning techniques & imputation", """
* **Fix corrupted data** - convert text-in-numbers to real numbers; unparseable entries become *missing*.
* **Placeholders** - `N/A`, `--`, `?`, `null` are not data; mark them missing.
* **Deletion** - drop *duplicate rows*, *sparse columns* (too little information) or *sparse rows*. Cheap but loses data.
* **Imputation** - fill gaps: **mean** (sensitive to outliers), **median** (robust), **KNN** (uses similar rows),
  **mode** (categories), or a constant. Choose based on distribution and how much is missing.
""")
    left, right = st.columns([1, 2.1])
    with left:
        st.markdown("#### Cleaning controls")
        fix = st.checkbox("Fix corrupted numeric columns", True, key="w_fix", help="Text → number; unparseable → missing")
        tok = st.checkbox("Convert placeholders (N/A, --, ?) to missing", True, key="w_tok")
        dup = st.checkbox("Remove duplicate rows", True, key="w_dup")
        thr = st.slider("Drop columns with more than X% missing", 5, 100, 50, key="w_colthr", help="100 = never drop columns")
        manual = st.multiselect("Also drop these columns", list(raw.columns), key="w_dropcols")
        use_row = st.checkbox("Drop rows with too many missing cells", False, key="w_userow")
        row_max = st.slider("…more than N missing cells", 0, max(raw.shape[1] - 1, 1), 2, key="w_rowmax") if use_row else None
        num_label = st.selectbox("Impute numeric columns with", list(NUM), index=0, key="w_num")
        const = st.number_input("Constant value", value=0.0, key="w_const") if NUM[num_label] == "constant" else 0.0
        cat_label = st.selectbox("Impute categorical columns with", list(CAT), index=0, key="w_cat")
    cfg = core.CleanConfig(fix, tok, dup, manual, float(thr), row_max, NUM[num_label], CAT[cat_label], float(const))
    out, log = _clean(raw, cfg)
    ss.pending[1] = out

    with right:
        qb, qa = core.quality_report(raw), core.quality_report(out)
        m = st.columns(4)
        m[0].metric("Rows", f"{len(out):,}", f"{len(out) - len(raw):+,}")
        m[1].metric("Columns", out.shape[1], f"{out.shape[1] - raw.shape[1]:+d}")
        m[2].metric("Missing cells", f"{qa['missing_cells']:,}", f"{qa['missing_cells'] - qb['missing_cells']:+,}", delta_color="inverse")
        m[3].metric("Duplicates", qa["duplicate_rows"], f"{qa['duplicate_rows'] - qb['duplicate_rows']:+d}", delta_color="inverse")
        t1, t2, t3 = st.tabs(["Before → After (real rows)", "Step-by-step log", "Missingness map"])
        with t1:
            problem = core.standardize_missing_tokens(raw).isna().any(axis=1) | raw.duplicated(keep=False)
            idx = [i for i in raw.index[problem] if i < len(out)][:8]
            st.caption("Rows that had problems in the raw data, and what the same row index looks like after cleaning "
                       "(row positions shift if rows were dropped).")
            a, b = st.columns(2)
            a.markdown("**Before**"); b.markdown("**After**")
            with a: ui.show_df(raw.loc[idx])
            with b: ui.show_df(out.loc[[i for i in idx if i in out.index]])
        with t2:
            ui.show_df(pd.DataFrame(log))
        with t3:
            f, axs = ui.fig(9, max(3, 0.28 * raw.shape[1] + 1), ncols=2, sharey=True)
            for ax, d, t in ((axs[0], qb, "Before"), (axs[1], qa, "After")):
                s = d["missing_by_col"].reindex(raw.columns).fillna(0)
                ax.barh(s.index, s.values); ax.set_title(f"{t}: % missing"); ax.set_xlim(0, 100)
                if (s == 0).all():
                    ax.text(50, len(s) / 2, "✓ no missing values", ha="center", va="center", fontsize=11, color="#2f9e44")
            ui.show_fig(f)
        st.download_button("⬇ Download cleaned CSV", out.to_csv(index=False).encode(), "cleaned_data.csv", "text/csv")

    left_missing = int(core.quality_report(out)["missing_cells"])
    ui.verdict(left_missing == 0 and len(out) > 0, "Dataset is complete - ready for exploration." if left_missing == 0 else
               f"{left_missing:,} missing cells remain (you chose to leave some un-imputed). Later steps skip them.")
    ui.record(1, "cleaning", "; ".join(f"{r['action']}: {r['detail']}" for r in log) or "No cleaning applied.")
    ui.record(1, "result", f"{len(raw):,}×{raw.shape[1]} → {len(out):,}×{out.shape[1]}; missing cells {qb['missing_cells']:,} → {left_missing:,}.")
    ui.proceed_bar(1, can_proceed=len(out) > 0, hint="Cleaning removed every row - relax the settings.")
