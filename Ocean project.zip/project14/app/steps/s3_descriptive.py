"""Step 4 - Descriptive analytics (Unit 3: statistics, bar / pie / line charts, dendrogram)."""
import numpy as np
import pandas as pd
import streamlit as st
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import squareform

import core
import ui


def render():
    ui.page_header(3, "Need for descriptive analytics · statistical techniques · bar, pie, line charts · dendrogram")
    df = st.session_state.data.get(2)
    if df is None:
        st.stop()
    nums = [c for c in df.columns if core.is_numeric(df[c])]
    cats = [c for c in df.columns if 2 <= df[c].nunique() <= 15 and (not core.is_numeric(df[c]) or df[c].nunique() <= 10)]
    ui.concept("Why descriptive analytics", """
Descriptive analytics answers **"what happened?"** by summarising the data: *central tendency* (mean, median, mode),
*spread* (variance, std, IQR, range, coefficient of variation) and *shape* (skewness, kurtosis), then communicating it with
**bar**, **pie** and **line** charts and a **dendrogram** (hierarchical clustering - which variables or rows are most alike).
""")
    t1, t2, t3, t4 = st.tabs(["Summary statistics", "Group-by", "Bar · Pie · Line", "Dendrogram"])
    with t1:
        sel = st.multiselect("Numeric columns", nums, default=core.default_numeric(df, nums, 8), key="w_dsel")
        if sel:
            d = core.describe_extended(df, sel)
            ui.show_df(d.round(3))
            skewed = d.index[d["skew"].abs() > 1].tolist()
            hi_cv = d.index[d["CV %"].abs() > 100].tolist()
            st.info("**Reading it:** " + (f"strongly skewed: {', '.join(skewed)} (prefer median/IQR). " if skewed else "no strongly skewed columns. ")
                    + (f"very high variability (CV > 100%): {', '.join(hi_cv)}." if hi_cv else ""))
        if cats:
            st.markdown("**Categorical summary**")
            ui.show_df(pd.DataFrame({c: {"unique": df[c].nunique(), "mode": df[c].mode().iloc[0],
                                         "mode share %": round((df[c] == df[c].mode().iloc[0]).mean() * 100, 1)} for c in cats}).T)
    with t2:
        if cats and nums:
            a, b, c = st.columns(3)
            g = a.selectbox("Group by", cats, key="w_gby"); v = b.selectbox("Measure", nums, key="w_gval")
            aggs = c.multiselect("Statistics", ["count", "mean", "median", "std", "min", "max"], default=["count", "mean", "median"], key="w_gagg")
            if aggs:
                res = df.groupby(g, observed=True)[v].agg(aggs).round(3)
                ui.show_df(res)
                if "mean" in aggs:
                    f, ax = ui.fig(6, 3.2); ax.bar(res.index.astype(str), res["mean"]); ax.set_ylabel(f"mean {v}"); ax.set_title(f"{v} by {g}")
                    ui.show_fig(f)
        else:
            st.info("Needs at least one categorical and one numeric column.")
    with t3:
        if not cats:
            st.info("No categorical columns for bar/pie charts.")
        else:
            a, b = st.columns(2)
            with a:
                st.markdown("**Bar chart**")
                bc = st.selectbox("Category", cats, key="w_barc")
                bm = st.selectbox("Value", ["(count of rows)"] + nums, key="w_barm")
                s = df[bc].astype(str).value_counts() if bm == "(count of rows)" else df.groupby(bc, observed=True)[bm].mean()
                s.index = s.index.astype(str)
                f, ax = ui.fig(5, 3.2); ax.bar(s.index, s.values); ax.set_title(("Count" if bm.startswith("(") else f"Mean {bm}") + f" by {bc}")
                ui.show_fig(f)
            with b:
                st.markdown("**Pie chart**")
                pc = st.selectbox("Category ", cats, key="w_piec")
                vc = df[pc].astype(str).value_counts()
                if len(vc) > 7:
                    vc = pd.concat([vc.head(6), pd.Series({"Other": vc.iloc[6:].sum()})])
                f, ax = ui.fig(5, 3.2)
                ax.pie(vc.values, labels=vc.index, autopct="%1.1f%%", colors=ui.PALETTE, startangle=90, wedgeprops={"edgecolor": "white"}); ax.grid(False)
                ui.show_fig(f)
        st.markdown("**Line chart**")
        ordered = [c for c in df.columns if core.is_numeric(df[c]) and df[c].nunique() > 5]
        if ordered:
            x = st.selectbox("X (e.g. day / time index)", ordered, index=ordered.index("day") if "day" in ordered else 0, key="w_linex")
            ycand = [c for c in nums if c != x]
            ydef = [c for c in ycand if not core.is_id_like(c, df[c])][-1:] or ycand[:1]        # last measured column, never an id
            ys = st.multiselect("Y (averaged per X)", ycand, default=ydef, key="w_liney")
            win = st.slider("Smoothing window (points)", 1, 15, 1, key="w_linew")
            if ys:
                g = df.groupby(x)[ys].mean().sort_index().rolling(win, min_periods=1).mean()
                f, ax = ui.fig(9, 3.4)
                for y in ys:
                    ax.plot(g.index, g[y], label=y, lw=1.8)
                ax.set_xlabel(x); ax.legend(); ui.show_fig(f)
    with t4:
        mode = st.radio("Cluster", ["Variables (by correlation)", "Rows (sample)"], horizontal=True, key="w_dmode")
        if mode.startswith("Var"):
            cols = st.multiselect("Variables", nums, default=core.default_numeric(df, nums, 12), key="w_dvars")
            if len(cols) >= 3:
                dist = 1 - df[cols].corr().abs().fillna(0).to_numpy(); np.fill_diagonal(dist, 0)
                Z = linkage(squareform((dist + dist.T) / 2, checks=False), "average")
                f, ax = ui.fig(8, 0.35 * len(cols) + 2.2); dendrogram(Z, labels=cols, orientation="left", ax=ax, color_threshold=0.6 * Z[:, 2].max())
                ax.set_xlabel("distance = 1 - |correlation|"); ax.grid(False); ui.show_fig(f)
                st.caption("Variables that join early (short branches) are strongly correlated and carry similar information.")
            else:
                st.info("Pick at least 3 variables.")
        else:
            cols = st.multiselect("Variables used", nums, default=core.default_numeric(df, nums, 8), key="w_dvars2")
            n = st.slider("Rows to sample", 10, 80, 30, key="w_dn")
            method = st.selectbox("Linkage", ["ward", "average", "complete", "single"], key="w_dlink")
            if len(cols) >= 2:
                d = df[cols].dropna(); d = d.sample(min(n, len(d)), random_state=1)
                z = (d - d.mean()) / d.std().replace(0, 1)
                Z = linkage(z.to_numpy(), method)
                f, ax = ui.fig(10, 3.6); dendrogram(Z, labels=[str(i) for i in d.index], ax=ax, color_threshold=0.7 * Z[:, 2].max(), leaf_font_size=7)
                ax.set_ylabel("distance"); ax.grid(False); ui.show_fig(f)
    ui.record(3, "descriptive", "Computed summary statistics (central tendency, spread, shape), grouped aggregates, bar/pie/line charts and a dendrogram.")
    ui.proceed_bar(3)
