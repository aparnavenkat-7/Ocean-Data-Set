"""Step 5 - Diagnostic analytics (Unit 4: inferential statistics, hypothesis testing, t-test, ANOVA, chi-square)."""
import numpy as np
import pandas as pd
import streamlit as st

import core
import ui


def _decision(p, alpha):
    return (f"p = {p:.3g} < α = {alpha} → **reject H₀** (statistically significant)" if p < alpha
            else f"p = {p:.3g} ≥ α = {alpha} → **fail to reject H₀** (no significant evidence)")


def render():
    ui.page_header(4, "Diagnostic analytics & inferential statistics · root causes · hypothesis testing · t-test · ANOVA · chi-square")
    df = st.session_state.data.get(2)
    if df is None:
        st.stop()
    nums = [c for c in df.columns if core.is_numeric(df[c]) and df[c].nunique() > 10]
    grp = [c for c in df.columns if 2 <= df[c].nunique() <= 15 and (not core.is_numeric(df[c]) or df[c].nunique() <= 10)]
    ui.concept("From 'what happened' to 'why did it happen'", """
Diagnostic analytics looks for **root causes**. We test claims about the population using a sample.
**H₀** (null) = no effect / no difference. **H₁** = there is one. The **p-value** is the probability of seeing data this extreme if H₀ were true;
if **p < α** (usually 0.05) we reject H₀.
**t-test**: compare two group means · **ANOVA**: compare 3+ group means · **Chi-square**: are two categorical variables associated?
Significance ≠ importance: always read the **effect size** too.
""")
    alpha = st.select_slider("Significance level α", [0.01, 0.05, 0.10], value=0.05, key="w_alpha")
    t1, t2, t3, t4 = st.tabs(["t-test (2 groups)", "ANOVA (3+ groups)", "Chi-square (categorical)", "Root-cause drivers"])
    found = []
    with t1:
        if nums and grp:
            a, b = st.columns(2)
            col = a.selectbox("Numeric variable", nums, key="w_tcol"); g = b.selectbox("Grouping variable", grp, key="w_tgrp")
            levels = sorted(df[g].dropna().astype(str).unique())
            a, b = st.columns(2)
            g1 = a.selectbox("Group 1", levels, key="w_tg1"); g2 = b.selectbox("Group 2", levels, index=min(1, len(levels) - 1), key="w_tg2")
            if g1 == g2:
                st.info("Pick two different groups.")
            else:
                r = core.t_test(df, col, g, g1, g2)
                st.markdown(f"**H₀:** mean `{col}` is the same in `{g}`={g1} and `{g}`={g2}  ·  **H₁:** the means differ (Welch two-sample t-test)")
                m = st.columns(4); m[0].metric(f"Mean ({g1})", f"{r['mean1']:.3g}", f"n={r['n1']}", delta_color="off")
                m[1].metric(f"Mean ({g2})", f"{r['mean2']:.3g}", f"n={r['n2']}", delta_color="off")
                m[2].metric("t statistic", f"{r['t']:.2f}"); m[3].metric("Cohen's d", f"{r['cohens_d']:.2f}")
                ui.verdict(r["p"] < alpha, _decision(r["p"], alpha))
                f, axs = ui.fig(9, 3.2, ncols=2)
                axs[0].hist(r["a"], bins=30, alpha=.55, density=True, label=g1); axs[0].hist(r["b"], bins=30, alpha=.55, density=True, label=g2); axs[0].legend()
                axs[1].boxplot([r["a"], r["b"]]); axs[1].set_xticks([1, 2]); axs[1].set_xticklabels([g1, g2])
                ui.show_fig(f)
                d = abs(r["cohens_d"]); st.caption(f"Effect size: {'negligible' if d < .2 else 'small' if d < .5 else 'medium' if d < .8 else 'large'} (|d| = {d:.2f}). "
                                                  "With thousands of rows even tiny differences become 'significant' - effect size tells you if it matters.")
                found.append(f"t-test {col} by {g} ({g1} vs {g2}): p={r['p']:.3g}, d={r['cohens_d']:.2f}")
        else:
            st.info("Needs a numeric variable and a categorical grouping variable.")
    with t2:
        multi = [c for c in grp if df[c].nunique() >= 3]
        if nums and multi:
            a, b = st.columns(2)
            col = a.selectbox("Numeric variable", nums, key="w_acol"); g = b.selectbox("Grouping variable (3+ levels)", multi, key="w_agrp")
            r = core.anova(df, col, g)
            st.markdown(f"**H₀:** all group means of `{col}` across `{g}` are equal  ·  **H₁:** at least one differs (one-way ANOVA)")
            m = st.columns(3); m[0].metric("F statistic", f"{r['F']:.2f}"); m[1].metric("p-value", f"{r['p']:.3g}"); m[2].metric("η² (effect size)", f"{r['eta2']:.3f}")
            ui.verdict(r["p"] < alpha, _decision(r["p"], alpha))
            f, ax = ui.fig(7, 3.4); names = list(r["groups"]); ax.boxplot([r["groups"][k] for k in names], patch_artist=True)
            ax.set_xticks(range(1, len(names) + 1)); ax.set_xticklabels(names); ax.set_ylabel(col); ui.show_fig(f)
            st.caption(f"η² = share of variance in `{col}` explained by `{g}` ({r['eta2'] * 100:.1f}%). ANOVA says *whether* groups differ, not *which* - follow up with pairwise t-tests.")
            found.append(f"ANOVA {col} by {g}: F={r['F']:.2f}, p={r['p']:.3g}, η²={r['eta2']:.3f}")
        else:
            st.info("Needs a numeric variable and a categorical variable with 3+ levels (e.g. quadrant).")
    with t3:
        allc = [c for c in df.columns if (2 <= df[c].nunique() <= 15) or (core.is_numeric(df[c]) and df[c].nunique() > 20)]
        if len(allc) >= 2:
            a, b = st.columns(2)
            c1 = a.selectbox("Variable A", allc, key="w_c1"); c2 = b.selectbox("Variable B", allc, index=min(1, len(allc) - 1), key="w_c2")
            if c1 == c2:
                st.info("Pick two different variables.")
            else:
                d = pd.DataFrame({c1: core.bin_if_continuous(df[c1]), c2: core.bin_if_continuous(df[c2])}).dropna()
                st.caption("Continuous columns are binned into quartiles so they can be cross-tabulated.")
                r = core.chi_square(d, c1, c2)
                st.markdown(f"**H₀:** `{c1}` and `{c2}` are independent  ·  **H₁:** they are associated (chi-square test of independence)")
                m = st.columns(4); m[0].metric("χ²", f"{r['chi2']:.2f}"); m[1].metric("dof", r["dof"]); m[2].metric("p-value", f"{r['p']:.3g}"); m[3].metric("Cramér's V", f"{r['cramers_v']:.3f}")
                ui.verdict(r["p"] < alpha, _decision(r["p"], alpha))
                a, b = st.columns(2)
                with a: st.markdown("**Observed counts**"); ui.show_df(r["observed"])
                with b: st.markdown("**Expected if independent**"); ui.show_df(r["expected"].round(1))
                if r["low_expected"]:
                    st.warning(f"{r['low_expected']} cells have expected count < 5 - the chi-square approximation may be unreliable.")
                pct = r["observed"].div(r["observed"].sum(axis=1), axis=0) * 100
                f, ax = ui.fig(7, 3.4); pct.plot(kind="bar", stacked=True, ax=ax, color=ui.PALETTE); ax.set_ylabel(f"% within {c1}"); ax.legend(title=c2, bbox_to_anchor=(1, 1)); ax.tick_params(axis="x", rotation=0)
                ui.show_fig(f)
                found.append(f"Chi-square {c1} × {c2}: χ²={r['chi2']:.1f}, p={r['p']:.3g}, V={r['cramers_v']:.2f}")
        else:
            st.info("Needs two categorical (or binnable numeric) columns.")
    with t4:
        st.markdown("**Root-cause screening:** rank every column by how strongly it is associated with an outcome (0 = none, 1 = perfect).")
        outcomes = [c for c in df.columns if (core.is_numeric(df[c]) and df[c].nunique() > 10) or df[c].nunique() <= 10]
        default = outcomes.index("convergence_zone") if "convergence_zone" in outcomes else 0
        target = st.selectbox("Outcome to explain", outcomes, index=default, key="w_drv_target")
        rk = core.driver_ranking(df, target)
        if len(rk):
            top = rk.head(15).iloc[::-1]
            f, ax = ui.fig(7, 0.32 * len(top) + 1.2); ax.barh(top["feature"], top["strength"]); ax.set_xlabel("association strength (0-1)"); ax.set_title(f"What is associated with `{target}`?")
            ui.show_fig(f)
            ui.show_df(rk.round(4))
            st.caption("Association ≠ causation. A column with strength ≈ 1 may be a *leak* (the outcome is derived from it), not a root cause - "
                       "check whether it could be known *before* the outcome happens.")
            found.append(f"Top drivers of {target}: " + ", ".join(rk['feature'].head(4)))
        else:
            st.info("Not enough usable columns.")
    if found:
        ui.record(4, "tests", " | ".join(found))
    ui.proceed_bar(4)
