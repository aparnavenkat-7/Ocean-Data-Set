"""OceanPlastic DA Lab - an interactive walk through the data-analytics lifecycle (5 syllabus units + report).

Run:  streamlit run app/app.py
"""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import streamlit as st  # noqa: E402

import ui  # noqa: E402
from steps import s0_upload, s1_cleaning, s2_eda, s3_descriptive, s4_diagnostic, s5_predictive, s6_report  # noqa: E402

PAGES = [s0_upload, s1_cleaning, s2_eda, s3_descriptive, s4_diagnostic, s5_predictive, s6_report]



class _QuietWidgetState(logging.Filter):
    """Widget values are deliberately kept alive across pages via session state; Streamlit logs a (harmless) notice for that."""

    def filter(self, record):
        return "had its value set via the Session State API" not in record.getMessage()


logging.getLogger("streamlit.elements.lib.policies").addFilter(_QuietWidgetState())

st.set_page_config(page_title="Ocean Plastic Analytics Lab", page_icon="🌊", layout="wide")
ui.init_state()
ss = st.session_state

with st.sidebar:
    st.markdown("## 🌊 OceanPlastic DA Lab")
    st.caption("Data Analytics lifecycle · SDG 14")
    unlocked = min(len(ss.done), len(ui.STEPS) - 1)
    for i, (name, icon, unit) in enumerate(ui.STEPS):
        mark = "✅" if i in ss.done else (icon if i <= unlocked else "🔒")
        ui.btn(f"{mark}  {i + 1}. {name}", key=f"nav_{i}", disabled=i > unlocked,
               type="primary" if i == ss.step else "secondary", on_click=ui.goto, args=(i,))
    st.progress(len(ss.done) / len(ui.STEPS), text=f"{len(ss.done)} of {len(ui.STEPS)} steps verified")
    cur = ss.data.get(max(ss.data)) if ss.data else None
    if cur is not None:
        st.caption(f"Current data: **{len(cur):,} rows × {cur.shape[1]} cols**")
    st.divider()
    st.caption("Complete each step, verify the output, then proceed. You can go back and change earlier steps; later steps will refresh.")

PAGES[ss.step].render()
