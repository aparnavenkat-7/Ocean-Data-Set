# Data-Driven Analytics of Ocean Plastic Accumulation
*Hydroacoustic signals, current patterns and convergence-zone prediction (SDG 14)*

Two parts in one repo:
1. **Web app** (`app/`) - an interactive walk through the data-analytics lifecycle: upload data, clean it, explore it, describe it, diagnose it, predict with it, report and monitor. Each page runs the real operation on *your* data and you verify the result before proceeding.
2. **MLOps pipeline** (`src/`, `main.py`) - production-style training, MLflow tracking, Prefect flows and drift alerts for the same ocean-plastic problem.

## Web app (start here)
```
python -m venv .venv
.venv\Scripts\activate            (Linux/macOS: source .venv/bin/activate)
pip install -r requirements.txt
streamlit run app\app.py          (opens http://localhost:8501)
```
Pick the built-in messy sample (Project 14 hydroacoustic data) or upload your own CSV/Excel.

| Page | Syllabus unit | What the user sees live |
|---|---|---|
| 1 Upload & Introduction | Unit 1 | Quantitative vs qualitative column types, missing / corrupted / duplicate-data profile |
| 2 Data Cleaning | Unit 1 | Fix corrupted values, placeholders, duplicates, drop sparse rows/columns, mean/median/KNN/mode imputation, before-vs-after rows and step log |
| 3 EDA | Unit 2 | Histogram, box, violin, frequency tables; scatter, correlation, covariance; heatmap, pair plot; IQR / Z-score outlier detection and treatment |
| 4 Descriptive | Unit 3 | Full statistics, group-by, bar / pie / line charts, dendrogram |
| 5 Diagnostic | Unit 4 | t-test, ANOVA, chi-square with decisions and effect sizes; root-cause driver ranking |
| 6 Predictive | Unit 5 | Features vs label, simple and multiple regression, logistic regression, SVM, leakage warnings, try-a-prediction form |
| 7 Report & Monitoring | wrap-up | Auto-generated findings report (.md), analysis-ready data (.csv), PSI drift check |

Pages unlock in order; going back to change a decision refreshes everything downstream. Built-in guardrails: identifier columns are not pre-selected, label-in-disguise (data leakage) is flagged, KNN imputation is capped at 5,000 rows, uploads over 50,000 rows are sampled.

## MLOps pipeline
End-to-end MLOps project: Phase 1 (data processing + EDA) and Phase 2 (OOP ML layer, MLflow tracking,
Prefect orchestration, concept-drift alerting with champion/challenger retraining).

## Run it (Windows CMD or any shell)
```
python -m venv .venv
.venv\Scripts\activate            (Linux/macOS: source .venv/bin/activate)
pip install -r requirements.txt

python main.py phase1             # synthetic data -> clean -> features -> EDA figures (reports\eda)
python main.py phase2             # Prefect training flow: classifier + current forecaster, MLflow, registry
python main.py monitor            # healthy batch -> expect severity=ok
python main.py monitor --drift    # drifted batch -> alert -> auto-retrain -> champion/challenger
python main.py all                # everything above
python -m pytest -q tests         # 25 tests (pipeline + web-app logic + full UI walkthrough)
python main.py reset              # wipe models, data, alerts, MLflow db (asks to confirm; --yes skips)

mlflow ui --backend-store-uri sqlite:///mlflow.db     # browse runs, metrics, registry
```

## Layout
| Path | Role |
|---|---|
| `src/opm/config.py` | One `Config` dataclass: grid, split, model, drift thresholds, MLflow URIs, webhook |
| `src/opm/synthetic.py` | Gyre + Ekman-convergence simulator with lagged plastic accumulation, dropouts, spikes, duplicates. **Replace with your real loader** (keep `RAW_COLUMNS`) |
| `src/opm/processing.py` | `DataProcessor` (fit/transform): validation, robust spike masking, imputation, divergence/vorticity from U/V grid, spectral features, lags, chronological splits, leakage guard |
| `src/opm/eda.py` | `EDAReport`: spectrum by class, spatial maps, correlations, distributions, time series, JSON summary |
| `src/opm/trainer.py` | `BaseTrainer` (ABC) -> `ConvergenceTrainer` (classifier, val-tuned F1 threshold, divergence-only baseline) and `DriftForecaster` (next-step u/v, persistence baseline) |
| `src/opm/tracking.py` | `Tracker`: MLflow experiment, params/metrics/importances, model registry, `champion` alias |
| `src/opm/drift.py` | `DriftDetector`: PSI + KS per feature, prediction-distribution PSI, delayed-label AUC drop (concept drift) |
| `src/opm/alerts.py` | `AlertManager`: log + `alerts/alerts.jsonl` + optional webhook (`ALERT_WEBHOOK_URL`, Slack-compatible) |
| `src/opm/pipeline.py` | Prefect `training_flow` and `monitoring_flow` (runs as plain Python if Prefect is absent) |

## Design decisions worth knowing
- **Time-based splits only.** Processor statistics are fit on training days only; lags are causal; `plastic_density`, the label and next-step targets are blocked from the feature list.
- **Drift triggers** (any one): >=20% of features with PSI>=0.25, prediction PSI>=0.25, or ROC-AUC drop >=0.05 once labels arrive. Tune in `Config`.
- **One drift reference.** Feature, prediction and AUC references all come from the held-out (val+test) data of the regime the champion was validated on. Mixing windows caused a false alert after retrains (fixed; regression-tested).
- **State persists between runs** (`models/`, `data/`, MLflow db). Run `python main.py reset` before a clean demo; otherwise an earlier drift-retrained champion will treat the 'healthy' demo batch as a regime change.
- **Retraining** uses all earlier data plus the first 60% of the new regime; val/test come from the new regime. The new model only becomes `champion` if it beats the incumbent on that same test set (PR-AUC for the classifier, RMSE for the forecaster).
- **Serving state** (processor, detector, threshold, model) lives in `models/champion_bundle.joblib`; the MLflow registry holds versions and the `champion` alias for lineage. Joblib/pickle files should only be loaded from sources you trust.
- MLflow 3 saves sklearn models with skops; `tracking.py` trusts only the one `HistGradientBoosting` internal type. Do not widen that list for third-party models.

## Reference results (synthetic data, seed 42)
- Classifier test: ROC-AUC 0.997, PR-AUC 0.974 vs 0.681 for a divergence-only baseline.
- Forecaster test RMSE 0.079 vs 0.084 for persistence (a small gain; day-to-day currents are highly persistent).
- Healthy batch: all PSI < 0.01, no alert. Drifted batch: 10/21 features in alert, prediction PSI 0.38, alert + retrain fired. The classifier challenger tied the champion (0.971 vs 0.972 PR-AUC) so it was not promoted; the forecaster challenger beat the champion (RMSE 0.085 vs 0.095) and was.
- These numbers are from simulated data. Expect lower scores on real hydrophone and current data, so re-baseline once you plug in the field dataset.
