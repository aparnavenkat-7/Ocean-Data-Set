"""CLI entrypoint.  python main.py phase1 | phase2 | monitor [--drift] | all | reset [--yes]"""
import argparse
import os
import logging
import shutil
import sys
from pathlib import Path

os.environ.setdefault("PREFECT_SERVER_ANALYTICS_ENABLED", "false")
sys.path.insert(0, str(Path(__file__).parent / "src"))

from opm.config import Config  # noqa: E402
from opm.eda import EDAReport  # noqa: E402
from opm.pipeline import monitoring_flow, training_flow  # noqa: E402
from opm.processing import DataProcessor  # noqa: E402
from opm.synthetic import generate_dataset  # noqa: E402


def phase1(cfg: Config):
    cfg.ensure_dirs()
    raw = generate_dataset(cfg)
    proc = DataProcessor(cfg).fit(DataProcessor(cfg).train_days(raw))
    feats = proc.transform(raw)
    summary = EDAReport(cfg).run(raw, feats)
    print(f"Phase 1 done: {len(raw)} raw -> {len(feats)} clean rows. Figures + summary in {cfg.reports_dir / 'eda'}")
    print("Top correlations with label:", summary["top_label_correlations"])


def reset(cfg: Config, assume_yes: bool):
    """Delete all generated state: models, data, alerts, MLflow db + artifacts. Source code and reports/eda stay."""
    targets = [cfg.models_dir, cfg.data_dir, cfg.alerts_dir, Path(cfg.root) / "mlartifacts", Path(cfg.root) / "mlruns"]
    files = [Path(cfg.root) / "mlflow.db"]
    print("This will delete:", ", ".join(str(t) for t in targets + files))
    if not assume_yes and input("Type yes to continue: ").strip().lower() != "yes":
        print("Aborted."); return
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    for f in files:
        f.unlink(missing_ok=True)
    cfg.ensure_dirs()
    print("Clean state. Now run: python main.py all")


def phase2(cfg: Config):
    out = training_flow(cfg)
    for k in ("classifier", "forecaster"):
        m = out[k]["metrics"]
        keys = [x for x in m if x.startswith("test_")]
        print(f"[{k}] promoted={out[k]['promoted']} v{out[k]['version']}  " + "  ".join(f"{x}={m[x]:.3f}" for x in keys))


def monitor(cfg: Config, drift: bool, days: int):
    out = monitoring_flow(cfg, n_days=days, simulate_drift=drift)
    r = out["report"]
    print(f"[monitor] batch={out['batch']} severity={r.severity} drift={r.drift_detected} retrained={out['retrained']}")
    for reason in r.reasons:
        print("   -", reason)
    for f in r.top(5):
        print(f"   {f['feature']:<20} PSI={f['psi']:.3f}  KS={f['ks_stat']:.3f}  [{f['severity']}]")
    if out["retrained"]:
        print("   retrain classifier:", {k: out["retrain"]["classifier"][k] for k in ("promoted", "version")})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["phase1", "phase2", "monitor", "all", "reset"])
    ap.add_argument("--drift", action="store_true", help="simulate sensor/current drift in the monitored batch")
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt for reset")
    ap.add_argument("--days", type=int, default=20)
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    cfg = Config()
    if a.command == "reset":
        reset(cfg, a.yes)
    elif a.command == "phase1":
        phase1(cfg)
    elif a.command == "phase2":
        phase2(cfg)
    elif a.command == "monitor":
        monitor(cfg, a.drift, a.days)
    else:
        phase1(cfg); phase2(cfg); monitor(cfg, False, a.days); monitor(cfg, True, a.days)
